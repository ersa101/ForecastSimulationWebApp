import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta


def predata(start_date, forecasting_period):
    
    ## Country-Operator-SAP_ID mapping
    ctry_op_sap = {'Country' : ['Tanzania', 'Tanzania', 'Malawi'],
                   'Operator' : ['Viettel', 'Tigo', 'Airtel'],
                   'SAP Customer No' : ['C4.V00001', 'C4.M00001', 'C11.A00003']}
    ctry_op_sap_df = pd.DataFrame(ctry_op_sap)
    print(f"pd0: {ctry_op_sap_df}\n")
    
    ## Generate MONTHS of forecasting period
    start_date = pd.to_datetime(start_date, format='%m/%Y')
    end_date = start_date + relativedelta(months = forecasting_period-1)
    date_values = []
    current_date = start_date
    while current_date <= end_date:
        date_values.append(current_date)
        current_date = current_date + relativedelta(months = 1)
    months = pd.DataFrame(date_values, columns=['months'])
    print(f"pd1: Shape of forecasting months is {months.shape}")
    print(f"pd2: Forecasting months table starts with {months.months.min()} & ends with {months.months.max()} \n")

    ## Frequency options
    freq = pd.DataFrame({'Escalation Frequency':['Monthly', 'Quarterly' ,'Bi-Annual', 'Annual'], 'freq_number':[1,3,6,12]})
    print(f"pd3: Shape of frequency period is {freq.shape}")
    print(f"pd4: Frequency Table looks like {freq} \n")

    ## usable parameter / lists
    # params = ["FX", "CPI change", "Fuel Escalation", "Electrical Escalation"] #, "Lease Rate"]
    # contri_params = ["CPI change", "Fuel Escalation", "Electrical Escalation"]
    # cond_params = conds.Parameter.unique()
    # imp_uncond_params = set(contri_params) - set(cond_params)

    ## creating a master BLR breakup data at Monthly level from CSV
    hist_blr_esc_cfv_master = pd.read_csv('rev_blr_esc_contri_facts.csv')
    hist_blr_esc_cfv_master = hist_blr_esc_cfv_master[hist_blr_esc_cfv_master.months < dt.datetime.now().strftime('%Y-%m-%d')]
    hist_blr_esc_cfv_master.rename(columns={'months' : 'Month', 'SAP_Customer_No' : 'SAP Customer No', 
                                            'Tenancy_Classification_Site_Billing_Type' : 'Site Tenancy Classification'}, inplace=True)
    hist_blr_esc_cfv_master['Month'] = pd.to_datetime(hist_blr_esc_cfv_master['Month'])
    print(f"pd4a: Table Size of master BLR breakup is {hist_blr_esc_cfv_master.shape} \n")
    

    # creating a hard coded previous values table     #####  NEED TO AUTOMATE IT 
    ## contributing params & BLRs
    hist = hist_blr_esc_cfv_master[hist_blr_esc_cfv_master.Month.isin([hist_blr_esc_cfv_master.Month.max()])]
    # hist['Month'] = hist['Month'] - pd.to_timedelta(hist['Month'].dt.day - 1, unit='d')
    # hist['Month'] = hist['Month'].dt.strftime("%B-%Y")
    print(f"pd5: Shape of base history table is {hist.shape} \n")

    ## filtering ESCs table
    esc_cols = [cols for cols in hist.columns if 'escmonthly__' in cols]
    esc_cols = ['Month', 'SAP Customer No', 'Site Tenancy Classification'] + esc_cols
    print(f"pd6: esc colnames are {esc_cols}")
    latest_esc = hist[esc_cols]
    print(f"pd7: Shape of escalation history table is {latest_esc.shape} \n")

    ## filtering GRID contri factors table
    contri_facts_cols = [cols for cols in hist.columns if 'cfv__' in cols]
    contri_facts_cols = ['Month', 'SAP Customer No', 'Site Tenancy Classification'] + contri_facts_cols
    print(f"pd8: contri factors colnames are {contri_facts_cols}")
    latest_contri = hist[contri_facts_cols]
    latest_contri['GridFactor'] = latest_contri[contri_facts_cols[1:]].sum(axis=0)
    print(f"pd9: Shape of GRID contribution factor history table is {latest_contri.shape} \n")

    ## filtering BLRs table
    blr_cols = [cols for cols in hist.columns if 'blr__' in cols]
    blr_cols = ['Month', 'SAP Customer No', 'Site Tenancy Classification'] + blr_cols
    print(f"pd10: BLRs colnames are {blr_cols}")
    latest_blr = hist[blr_cols]
    print(f"pd11: Shape of BLRs history table is {latest_blr.shape} \n")

    
    return months, freq, ctry_op_sap_df, latest_blr, latest_esc, latest_contri, hist_blr_esc_cfv_master #, params, contri_params, cond_params, imp_uncond_params


def baselease(base_lease, start_date, forecasting_period):

    months, freq, ctry_op_sap_df, latest_blr, latest_esc, latest_contri, hist_blr_esc_cfv_master = predata(start_date, forecasting_period)
    
    ##  latest BLRs for all classes
    class_prev_blr = latest_blr.merge(ctry_op_sap_df, on = 'SAP Customer No', how = 'inner')
    class_prev_blr = class_prev_blr.drop(['Country', 'SAP Customer No'], axis=1)
    print(f"b1: shape of hist_blr_brkup_master is {class_prev_blr.shape} \n which looks like \n {class_prev_blr.head(3)} \n")
    oldcolname = list(class_prev_blr.columns)
    col_to_match = [col for col in class_prev_blr.columns if 'blr__' not in col]
    newcolname = [col.split('__')[3] if col not in col_to_match else col for col in oldcolname]
    print(f"b1.1: new required column names will be {newcolname}")
    col_rename_dict = dict(zip(class_prev_blr.columns, newcolname))
    class_prev_blr.rename(columns=col_rename_dict, inplace=True)
    print(f"b1.2: updated colname after change is {class_prev_blr.columns} \n")

    if base_lease.shape[0] == 0:
        print('OK')
        changed_locs = []
        # base_lease = class_prev_blr.copy()
    else:
        changed_locs = base_lease['Site Tenancy Classification'].unique()
        pvt = base_lease.pivot_table(values='Base Rate', index=['Operator', 'Site Tenancy Classification', 'Month'], columns='Change Parameter')
        pvt = pvt.reset_index()
        base_lease = pvt.copy()
        print(f"b1.3 Shape of USER BLR input Data after PIVOT is {base_lease.shape} which looks like \n {base_lease}")
        
    locs = class_prev_blr['Site Tenancy Classification'].unique()
    print(f"b1.4: total classes are : {len(locs)}")
    # changed_locs = base_lease['Site Tenancy Classification'].unique()
    unchanged_locs = set(locs) - set(changed_locs)
    print(f"b2: all site classes {locs} \n  site classes whose future BLR are changed {changed_locs} \n  site classes whose future BLR are unchanged {unchanged_locs} \n")

    # class_future_blr_cols = ['Location', 'months', 'Base Rate', 'Addon Rate']
    # class_future_blr_cols = ['Site Tenancy Classification', 'Month', 'Diesel', 'Electricity', 'NonPower']
    # class_future_blr_cols = ['Operator', 'Site Tenancy Classification', 'Month'] + [cols for cols in latest_blr.columns if 'blr__' in cols]
    # class_future_blr = pd.DataFrame(columns = class_future_blr_cols)
    class_future_blr = pd.DataFrame()

    # base_lease['Month'] = pd.to_datetime(base_lease['Month'])
    # base_lease = base_lease.sort_values(by=['Site Tenancy Classification', 'Month'], ascending = [True, True])

    ## those params which are important and contributing and changed in conditions provided
    if base_lease.shape[0] > 0:
        base_lease['Month'] = pd.to_datetime(base_lease['Month'])
        base_lease = base_lease.sort_values(by=['Site Tenancy Classification', 'Month'], ascending = [True, True])
        for k in locs:
            if k in changed_locs:
                df = base_lease[base_lease['Site Tenancy Classification'].isin([k])].merge(months, how = 'right', left_on = ['Month'], right_on = 'months')
                # df = df[['Site Tenancy Classification', 'months', 'Diesel', 'Electricity', 'NonPower']]
                df = df.drop('Month', axis=1)
                df.rename(columns = {'months':'Month'}, inplace=True)
                df = df.sort_values(by='Month')
                # print(f"b3: for {k} with shape {df.shape} \n {df.head(3)}")
                
                temp = class_prev_blr[class_prev_blr['Site Tenancy Classification'] == k]

                df2 = pd.concat([temp, df], ignore_index=True)
                df2.fillna(0, inplace=True)
                print(f"b3.1 shape is {df2.shape} \n which looks like \n {df2.head(3)}")
                df2['Site Tenancy Classification'] = k

                for l in range(1, df2.shape[0]):
                    for m in range(2, df2.shape[1]):
                        if df2.iloc[l,m] == 0:
                            df2.iloc[l,m] = df2.iloc[l-1,m]
                # print("df2", df2.head(10), "\n") 

                class_future_blr = pd.concat([class_future_blr, df2], ignore_index=True)
                # print(f"b.4: class_future_blr has shape {class_future_blr.shape} and looks like \n {class_future_blr.head(3)}")
                
        for p in list(unchanged_locs):
            df2 = class_prev_blr[class_prev_blr['Site Tenancy Classification'].isin([p])].merge(months, how = 'right', left_on = ['Month'], right_on = 'months')
            df2 = df2.drop('Month', axis=1)
            df2.rename(columns = {'months':'Month'}, inplace=True)
            df2 = df2.sort_values(by='Month')
            temp = class_prev_blr[class_prev_blr['Site Tenancy Classification'] == p]

            df2 = pd.concat([temp, df2], ignore_index=True)
            # print(f"b.5: for {p} with shape {df2.shape} \n {df2.head(3)}")

            df2['Site Tenancy Classification'] = p
            df2.fillna(0, inplace=True)

            for q in range(1, df2.shape[0]):
                for r in range(2, df2.shape[1]):
                    if df2.iloc[q,r] == 0:
                        df2.iloc[q,r] = df2.iloc[q-1,r]
            # print("df2", df2.head(10), "\n") 

            class_future_blr = pd.concat([class_future_blr, df2], ignore_index=True)
            # print(f"b.6: class_future_blr has shape {class_future_blr.shape} and looks like \n {class_future_blr.head(3)}")
                
        # class_future_blr['BaseLeaseRate_tzs'] = class_future_blr['Diesel'] + class_future_blr['Electricity'] + class_future_blr['NonPower']
        # class_future_blr['BaseLeaseRate_usd'] = class_future_blr['BaseLeaseRate_tzs'] / 1616.56

        print(f"b7: colnames are {class_future_blr.columns}")
        print(f"b7.1: min date is {class_future_blr.Month.min()}")
        # class_future_blr = class_future_blr[~(class_future_blr['Month'] == hist_blr.months.max())]
        class_future_blr['Month'] = pd.to_datetime(class_future_blr['Month'])
        class_future_blr = class_future_blr[class_future_blr.Month > latest_blr.Month.max()]
        class_future_blr['Month'] = class_future_blr['Month'].dt.strftime('%Y-%m-%d')
        # class_future_blr = class_future_blr[~(class_future_blr['Month'] == '2023-12-01')]
        print(f"b.7.1: class_future_blr looks like {class_future_blr.head(3)}")
        
        print("b.8: final class_future_blr", class_future_blr.shape, "\n Which is ", class_future_blr.shape[0] == ((months.shape[0]) * len(locs)))
        # print("final class_future_blr", class_future_blr.shape, "\n Which is ", class_future_blr.shape[0] == ((months.shape[0] + 1) * len(locs)))

    else:
        class_prev_blr['Month'] = pd.to_datetime(class_prev_blr['Month'])
        class_prev_blr = class_prev_blr.sort_values(by=['Site Tenancy Classification', 'Month'], ascending = [True, True])

        for p in list(unchanged_locs):
            df2 = class_prev_blr[class_prev_blr['Site Tenancy Classification'].isin([p])].merge(months, how = 'right', left_on = ['Month'], right_on = 'months')
            df2 = df2.drop('Month', axis=1)
            df2.rename(columns = {'months':'Month'}, inplace=True)
            df2 = df2.sort_values(by='Month')
            temp = class_prev_blr[class_prev_blr['Site Tenancy Classification'] == p]

            df2 = pd.concat([temp, df2], ignore_index=True)
            # print(f"b.5: for {p} with shape {df2.shape} \n {df2.head(3)}")

            df2['Site Tenancy Classification'] = p
            df2.fillna(0, inplace=True)

            for q in range(1, df2.shape[0]):
                for r in range(2, df2.shape[1]):
                    if df2.iloc[q,r] == 0:
                        df2.iloc[q,r] = df2.iloc[q-1,r]
            # print("df2", df2.head(10), "\n") 

            class_future_blr = pd.concat([class_future_blr, df2], ignore_index=True)
            # print(f"b.6: class_future_blr has shape {class_future_blr.shape} and looks like \n {class_future_blr.head(3)}")
                
        # class_future_blr['BaseLeaseRate_tzs'] = class_future_blr['Diesel'] + class_future_blr['Electricity'] + class_future_blr['NonPower']
        # class_future_blr['BaseLeaseRate_usd'] = class_future_blr['BaseLeaseRate_tzs'] / 1616.56

        print(f"b7: colnames are {class_future_blr.columns}")
        print(f"b7.1: min date is {class_future_blr.Month.min()}")
        # class_future_blr = class_future_blr[~(class_future_blr['Month'] == hist_blr.months.max())]
        class_future_blr['Month'] = pd.to_datetime(class_future_blr['Month'])
        # class_future_blr = class_future_blr[class_future_blr.Month > latest_blr.Month.max()]
        class_future_blr['Month'] = class_future_blr['Month'].dt.strftime('%Y-%m-%d')
        # class_future_blr = class_future_blr[~(class_future_blr['Month'] == '2023-12-01')]
        print(f"b.7.1: class_future_blr looks like {class_future_blr.head(3)}")
        
        print("b.8: final class_future_blr", class_future_blr.shape, "\n Which is ", class_future_blr.shape[0] == ((months.shape[0]) * len(locs)))
        # print("final class_future_blr", class_future_blr.shape, "\n Which is ", class_future_blr.shape[0] == ((months.shape[0] + 1) * len(locs)))

    
    class_future_blr = class_future_blr.drop_duplicates()
    
    cols_to_change = list(class_future_blr.columns)
    col_to_ignore = ['Month', 'Site Tenancy Classification' , 'Operator']
    newcolnames = ['blr__' + col if col not in col_to_ignore else col for col in cols_to_change]
    # print(newcolnames)
    col_rename_dict = dict(zip(class_future_blr.columns, newcolnames))
    class_future_blr.rename(columns=col_rename_dict, inplace=True)
    # print(class_future_blr.columns,"\n")
    

    return class_future_blr, class_prev_blr #, blr_cols ## class_future_blr_pivot


def esc(conds, base_lease, start_date, forecasting_period):

    months, freq, ctry_op_sap_df, latest_blr, latest_esc, latest_contri, hist_blr_esc_cfv_master = predata(start_date, forecasting_period)
    class_future_blr, class_prev_blr = baselease(base_lease, start_date, forecasting_period)

    base_all = pd.DataFrame()

    ##  latest BLRs for all classes
    class_prev_esc = latest_esc.merge(ctry_op_sap_df, on = 'SAP Customer No', how = 'inner')
    class_prev_esc = class_prev_esc.drop(['Country', 'SAP Customer No'], axis=1)
    print(f"e1: shape of hist_blr_brkup_master is {class_prev_esc.shape} \n which looks like \n {class_prev_esc.head(3)} \n")
    oldcolname = list(class_prev_esc.columns)
    col_to_match = [col for col in class_prev_esc.columns if 'escmonthly__' not in col]
    newcolname = [col.split('__')[1] if col not in col_to_match else col for col in oldcolname]
    print(f"e1.1: new required column names will be {newcolname}")
    col_rename_dict = dict(zip(class_prev_esc.columns, newcolname))
    class_prev_esc.rename(columns=col_rename_dict, inplace=True)
    print(f"e1.2: updated colname after change is {class_prev_esc.columns} \n")

    ## conditional table
    if conds.shape[0]==0:
        print('ok')
        changed_classes = []
        # conds = class_prev_esc.copy()
    else:
        changed_classes = list(conds['Site Tenancy Classification'].unique())
        conds.rename(columns={'Start Month':'Month'}, inplace=True)
        conds['Month'] = pd.to_datetime(conds['Month'])
    print(f"e1.4: {conds.shape}")

    # adding operator details
    esc_cols = [cols.split('__')[1] for cols in latest_esc.columns if 'escmonthly__' in cols]
    print(f"e2: esc_cols are {esc_cols}\n")
    class_prev_esc['Month'] = pd.to_datetime(class_prev_esc['Month'])
    class_prev_esc = class_prev_esc.sort_values(by=['Site Tenancy Classification', 'Month'], ascending = [True, True])
    print(f"e3: prev_esc looks like \n {class_prev_esc} \n")

    all_params = esc_cols
    
    print(f"e3.2 changed_classes are {changed_classes}")
    unchanged_classes = set(class_prev_esc['Site Tenancy Classification'].unique()) - set(changed_classes)


    # generating a table with imp_conds monthly variation
    ## filtering previous values
    ## AUTOMATE IT
    prev_vals = class_prev_esc.copy()
    print(prev_vals.columns)

        
    ## those params which are important and contributing and changed in conditions provided
    if conds.shape[0]>0:
        for sc in changed_classes:
            base = pd.DataFrame()
            print(sc)
            df0 =  conds[conds['Site Tenancy Classification'] == sc]
            # print(f"e3.1 df0 looks \n {df0}")
            cond_params = list(df0.Parameter.unique())
            # print(f"e3.1: cond_params are {cond_params}")
            uncond_params = set(all_params) - set(cond_params)
            # print(f"e3.1.1: cond_params are {uncond_params}")
            # for k in all_params:
            for k in cond_params:
                # df0 =  conds[conds['Site Tenancy Classification'] == sc]
                # print(f"e3.1 df0 looks \n {df0}")
                df = df0[df0.Parameter.isin([k])].merge(freq, how = 'left', on='Escalation Frequency')
                df2 = df.merge(months, how = 'right', left_on = ['Month'], right_on = 'months')
                df2.rename(columns={'Value':'percent'}, inplace=True)
                df2 = df2.sort_values(by='months')
                # print("df2 details ", sc, "\n", df2.head(15))

                ##############################################################################################################

                ## creating a filtered table for various month change
                chk = df.copy()
                additional_row = pd.DataFrame({'Month': [df2.months.max()], 'percent': [0], 'freq_number': [0]})
                chk = pd.concat([chk, additional_row], ignore_index=True)
                # chk = pd.concat([chk, pd.DataFrame({'Month':df2.months.max(), 'percent':0, 'freq_number':0})], ignore_index=True)
                chk['mnths'] = ''
                # print("chk details ", k, chk.shape, "\n", chk)

                for i in range(chk.shape[0]-2):
                    # print(chk.iloc[i,4])
                    strt_dt, end_dt, interval = chk.iloc[i,3], chk.iloc[i+1,3], int(chk.iloc[i,6])
                    # print(chk.iloc[i,3], chk.iloc[i+1,3], chk.iloc[i,6])
                    date_values = []
                    while strt_dt < end_dt:
                        strt_dt = strt_dt + relativedelta(months=interval)
                        date_values.append(strt_dt.strftime('%Y-%m-%d'))
                    date_values = str(date_values[:-1])
                    chk.iloc[i,8] = date_values

                for j in range(chk.shape[0]-2, chk.shape[0]-1):
                    strt_dt, end_dt, interval = chk.iloc[j,3], chk.iloc[j+1,3], int(chk.iloc[j,6])
                    # print(chk.iloc[j,3], chk.iloc[j+1,3], chk.iloc[j,6])
                    date_values = []
                    while strt_dt <= end_dt:
                        strt_dt = strt_dt + relativedelta(months=interval)
                        date_values.append(strt_dt.strftime('%Y-%m-%d'))
                    date_values = str(date_values[:-1])
                    chk.iloc[j,8] = date_values

                chk['mnths'] = chk['mnths'].str.replace('[', '').str.replace(']', '').str.replace("'", '')

                ##############################################################################################################

                ## expanding offset column values
                dt_list =  chk[['mnths']].dropna()
                dt_list['num_elements'] = dt_list['mnths'].str.count(',') + 1

                expanded_df = pd.DataFrame()

                for index, row in dt_list.iterrows():
                    dates_list = row['mnths'].split(', ')
                    num_elements = row['num_elements']

                    for i in range(num_elements):
                        additional_row = pd.DataFrame({'mnths': [dates_list[i]], 'original_mnths': [row['mnths']]})
                        expanded_df = pd.concat([expanded_df, additional_row], ignore_index=True)

                dt_list = dt_list.drop(['mnths', 'num_elements'], axis=1)
                result_df = pd.concat([dt_list, expanded_df], ignore_index=True).dropna()
                result_df.rename(columns={'mnths':'nxt_mnths', 'original_mnths':'mnths'}, inplace=True)

                ##############################################################################################################

                ## mapping expanded dates with the base file
                # print(f"e4.0: chk looks like \n {chk.head(10)} \n result_df looks like \n {result_df.head(10)}")
                chk2 = chk.merge(result_df, how = 'left', on = 'mnths')
                chk2['nxt_mnths'] = pd.to_datetime(chk2['nxt_mnths'])

                # print(f"e4.0a: df2 looks like \n {df2.head(10)} \n chk2 looks like \n {chk2.head(10)}")
                chk3 = df2.merge(chk2, how='left', left_on='months', right_on='nxt_mnths')
                # print(f"e4: chk3 colnames are : {chk3.columns} which looks like \n {chk3}")

                chk3['percent'] = np.where((chk3.percent_x.isna()) & (chk3.Value.isna()), np.NaN,
                                            np.where((chk3.percent_x.isna()),chk3.Value, chk3.percent_x))
                # chk3['Parameter'] = np.where((chk3.Parameter_x.isna()) & (chk3.Parameter_y.isna()), np.NaN,
                #                             np.where((chk3.Parameter_x.isna()),chk3.Parameter_y, chk3.Parameter_x))
                chk3['freq_number'] = np.where((chk3.freq_number_x.isna()) & (chk3.freq_number_y.isna()), np.NaN,
                                            np.where((chk3.freq_number_x.isna()),chk3.freq_number_y, chk3.freq_number_x))
                chk3['Escalation Frequency'] = np.where((chk3['Escalation Frequency_x'].isna()) & (chk3['Escalation Frequency_y'].isna()), np.nan,
                                            np.where((chk3['Escalation Frequency_x'].isna()),chk3['Escalation Frequency_y'], chk3['Escalation Frequency_x']))
                # chk3['Month'] = np.where((chk3['Month_x'].isna()) & (chk3['Month_y'].isna()), np.datetime64("NaT"),
                #                             np.where((chk3['Month_x'].isna()),chk3['Month_y'], chk3['Month_x']))

                ops = chk3['Operator_x'].dropna().unique()
                chk3['Operator'] = ops[0]
                chk3['Parameter'] = k
                chk3['Site Tenancy Classification'] = sc

                chk4 = chk3[['Operator', 'Site Tenancy Classification', 'Parameter', 'months', 'percent', 'Escalation Frequency', 'freq_number']]
                chk4.rename(columns={'months':'Month'}, inplace=True)
                # print(f"e5: {chk4.columns}")
                # print(f"e6: chk4 table \n {chk4}")
                

                # print(f"e7: prev_vals looks like {prev_vals.head(1)}")
                col_to_match = ['Month', 'Site Tenancy Classification', 'Operator'] + [col for col in prev_vals.columns if col.startswith(k)]
                # print(f"e8: col_to_match looks like {col_to_match}")
                
                temp = prev_vals[prev_vals['Site Tenancy Classification'] == sc][col_to_match]
                temp.rename(columns={k:'percent'}, inplace=True)
                
                # print(f"e8.1 temp table looks like \n {temp.head(3)}  \n chk4 looks like \n {chk4.head(3)}")
                chk5 = pd.concat([temp, chk4], ignore_index=True)
                chk5.percent.fillna(0, inplace=True)
                chk5['CummPerc'] = chk5.percent.cumsum()
                chk5['MonthlyPerc'] = np.where(pd.isna(chk5.percent), np.NaN, chk5.percent)
                chk5['Month'] = pd.to_datetime(chk5['Month'])
                chk5['Month'] = chk5['Month'].dt.strftime('%Y-%m-%d')
                # print(f"e9: chk5 looks like \n {chk5}")
                
                for i in range(1, chk5.shape[0]):
                    if chk5.iloc[i, chk5.columns.get_loc('percent')] != 0:
                        chk5.iloc[i, chk5.columns.get_loc('MonthlyPerc')] = chk5.iloc[i, chk5.columns.get_loc('percent')]
                    else:
                        chk5.iloc[i,chk5.columns.get_loc('MonthlyPerc')] = float(chk5.iloc[i-1, chk5.columns.get_loc('FinalPerc')])
                        
    
                chk5.rename(columns={ #'GridVal':f"{k}_GridVal", 'OffGridVal':f"{k}_OffGridVal", 
                                        'CummPerc':f"{k}_CummPerc", 'percent':k, 'Escalation Frequency':f"{k}_freq", 'MonthlyPerc':f"{k}_MonthlyPerc",}
                            , inplace = True)
                chk5.drop(['Parameter', 'freq_number'], axis=1, inplace=True)
 

                if base.shape[0] == 0:
                    base = chk5.copy()
                else:
                    base = base.merge(chk5, on=['Month', 'Site Tenancy Classification', 'Operator'], how='left')
                # print("e11: input conditions' name, shape & base forecast file shape resp. are :", sc, k, chk5.shape, base.shape, "\n")

            # print(f"cond {base.info()}")

            # those params which are important and contributing but not changed in conditions provided
            for h in list(uncond_params):   
                col_to_match = ['Month', 'Site Tenancy Classification', 'Operator'] + [col for col in prev_vals.columns if col.startswith(h)]
                temp = prev_vals[prev_vals['Site Tenancy Classification'] == sc][col_to_match]
                # print(temp)
                future_months = months.copy()
                future_months.rename(columns={'months':'Month'}, inplace=True)
                temp_uncond_params =  future_months.merge(temp, on='Month', how= 'outer')
                temp_uncond_params.sort_values('Month', inplace=True)
                # print(temp_uncond_params.head(3), "\n")

                temp_uncond_params['Site Tenancy Classification'] = sc
                temp_uncond_params['Operator'] = temp_uncond_params['Operator'].dropna().unique()[0]
                temp_uncond_params[f"{h}_MonthlyPerc"] = temp_uncond_params[h].dropna().unique()[0]
                temp_uncond_params[f"{h}_CummPerc"] =  temp_uncond_params[h].dropna().unique()[0]

                temp_uncond_params['Month'] = pd.to_datetime(temp_uncond_params['Month'])
                temp_uncond_params['Month'] = temp_uncond_params['Month'].dt.strftime('%Y-%m-%d')
                # print(f"uncond {temp_uncond_params.info()}")
                # print(f"e11.1 : {temp_uncond_params.head(3)}")

                if base.shape[0] == 0:
                    base = temp_uncond_params.copy()
                else:
                    base = base.merge(temp_uncond_params, on=['Month', 'Site Tenancy Classification', 'Operator'], how='left')
                # print("e12: input conditions' name, shape & base forecast file shape resp. are :", sc, h, temp_uncond_params.shape, base.shape, "\n")

            
        #         temp_uncond_params['Month'] = pd.to_datetime(temp_uncond_params['Month'])
        #         base = base.merge(temp_uncond_params, on='Month', how = 'left')
        #         print("input conditions' name, shape & base forecast file shape resp. are :", h, temp_uncond_params.shape, base.shape, "\n")

            base_all = pd.concat([base_all, base], ignore_index=True)
            # print("final forecast base table has R*C as ", base_all.shape)  



        for usc in unchanged_classes:
            base_usc = pd.DataFrame()
            print(usc)
            df0 =  prev_vals[prev_vals['Site Tenancy Classification'] == usc]
            # print(df0)
            joiners= ['Month', 'Site Tenancy Classification', 'Operator']
            cols = [col for col in df0.columns if col not in joiners]
            # print(cols)
            for e in cols:
                temp = df0[joiners + [e]]
                # print(temp)

                future_months = months.copy()
                future_months.rename(columns={'months':'Month'}, inplace=True)

                temp2 =  future_months.merge(temp, on='Month', how= 'outer')
                temp2.sort_values('Month', inplace=True)
                # print(temp2.head(3), "\n")

                temp2['Site Tenancy Classification'] = usc
                temp2['Operator'] = temp2['Operator'].dropna().unique()[0]
                temp2[f"{e}_MonthlyPerc"] = temp2[e].dropna().unique()[0]
                temp2[f"{e}_CummPerc"] =  temp2[e].dropna().unique()[0]

                temp2['Month'] = pd.to_datetime(temp2['Month'])
                temp2['Month'] = temp2['Month'].dt.strftime('%Y-%m-%d')
                # print(f"unchanged SCs {temp2.info()}")
                # print(f"unchanged SCs {temp2.columns}")
                # print(f"e11.1 : {temp2.head(3)}")

                if base_usc.shape[0] == 0:
                    base_usc = temp2.copy()
                else:
                    base_usc = base_usc.merge(temp2, on=['Month', 'Site Tenancy Classification', 'Operator'], how='left')
                # print("e12: input conditions' name, shape & base forecast file shape resp. are :", sc, h, temp_uncond_params.shape, base.shape, "\n")
                # print(base_usc.head(3))

            base_all = pd.concat([base_all, base_usc], ignore_index=True)
            # print("final forecast base table has R*C as ", base_all.shape)

        print("final base table has R*C as ", base_all.shape)
        print("final base table has colnames as ", base_all.columns)

        perc = [col for col in base_all.columns if 'percent' in col]
        cummperc = [col for col in base_all.columns if 'CummPerc' in col]
        finalperc = [col for col in base_all.columns if 'MonthlyPerc' in col]
        filtr_cols = perc + cummperc + finalperc
        filtr_cols = col_to_match + filtr_cols
        class_future_esc = base_all[filtr_cols]
        class_future_esc['Month'] = pd.to_datetime(class_future_esc['Month'])
        class_future_esc = class_future_esc[class_future_esc.Month > latest_esc.Month.max()]
        class_future_esc['Month'] = class_future_esc['Month'].dt.strftime('%Y-%m-%d')
    
    else:
        for usc in unchanged_classes:
            base_usc = pd.DataFrame()
            print(usc)
            df0 =  prev_vals[prev_vals['Site Tenancy Classification'] == usc]
            print(df0)
            joiners= ['Month', 'Site Tenancy Classification', 'Operator']
            cols = [col for col in df0.columns if col not in joiners]
            # print(cols)
            for e in cols:
                temp = df0[joiners + [e]]
                # print(temp)

                future_months = months.copy()
                future_months.rename(columns={'months':'Month'}, inplace=True)

                temp2 =  future_months.merge(temp, on='Month', how= 'outer')
                temp2.sort_values('Month', inplace=True)
                # print(temp2.head(3), "\n")

                temp2['Site Tenancy Classification'] = usc
                temp2['Operator'] = temp2['Operator'].dropna().unique()[0]
                temp2[f"{e}_MonthlyPerc"] = temp2[e].dropna().unique()[0]
                temp2[f"{e}_CummPerc"] =  temp2[e].dropna().unique()[0]

                temp2['Month'] = pd.to_datetime(temp2['Month'])
                temp2['Month'] = temp2['Month'].dt.strftime('%Y-%m-%d')
                # print(f"unchanged SCs {temp2.info()}")
                # print(f"unchanged SCs {temp2.columns}")
                # print(f"e11.1 : {temp2.head(3)}")

                if base_usc.shape[0] == 0:
                    base_usc = temp2.copy()
                else:
                    base_usc = base_usc.merge(temp2, on=['Month', 'Site Tenancy Classification', 'Operator'], how='left')
                # print("e12: input conditions' name, shape & base forecast file shape resp. are :", sc, h, temp_uncond_params.shape, base.shape, "\n")
                # print(base_usc.head(3))

            base_all = pd.concat([base_all, base_usc], ignore_index=True)
            # print("final forecast base table has R*C as ", base_all.shape)

        print("final base table has R*C as ", base_all.shape)
        print("final base table has colnames as ", base_all.columns)

        # perc = [col for col in base_all.columns if 'percent' in col]
        # cummperc = [col for col in base_all.columns if 'CummPerc' in col]
        # finalperc = [col for col in base_all.columns if 'FinalPerc' in col]
        # filtr_cols = perc + cummperc + finalperc
        # filtr_cols = col_to_match + filtr_cols
        
        class_future_esc = base_all.copy()
        class_future_esc['Month'] = pd.to_datetime(class_future_esc['Month'])
        class_future_esc['Month'] = class_future_esc['Month'].dt.strftime('%Y-%m-%d')

    return class_future_esc # ,blr_esc



def forecast_logic(conds, base_lease, start_date, forecasting_period):
    
    months, freq, ctry_op_sap_df, latest_blr, latest_esc, latest_contri, hist_blr_esc_cfv_master = predata(start_date, forecasting_period)
    class_future_blr, class_prev_blr = baselease(base_lease, start_date, forecasting_period)
    class_future_esc = esc(conds, base_lease, start_date, forecasting_period)
    
    class_future_esc_blr = class_future_esc.merge(class_future_blr, on= ['Month', 'Site Tenancy Classification', 'Operator'], how='inner')
    print(f"{class_future_esc_blr.shape} which is {class_future_esc_blr.shape[0] == class_future_esc.shape[0]}")
    print(f"colnames are {class_future_esc_blr.columns}")
    
    future_esc_blrs = pd.DataFrame()

    for i in  class_future_esc_blr['Site Tenancy Classification'].unique():
        temp = class_future_esc_blr[class_future_esc_blr['Site Tenancy Classification'] == i]
        # print(temp.shape)
        cols_to_ignore = ['Month', 'Site Tenancy Classification', 'Operator']
        cols_to_check = [col.split('__')[1] for col in temp.columns if (len(col.split('__'))==2 and 'blr__' in col)]
        # print(f"cols_to_check are {cols_to_check}")
        store_rev_blr_df = pd.DataFrame()
        for j in cols_to_check:
            # print(j)
            req_cols = cols_to_ignore + ["blr__"+j] + [col for col in temp.columns if col.startswith(j)]
            # print(f"req_cols are {req_cols}")
            temp2 = temp[req_cols]
            temp2[f'{j}_EscBlr'] = temp2[f'blr__{j}'] * (1 + (temp2[f'{j}_MonthlyPerc'] / 100))
            # print(f"temp2 colnames are {temp2.columns} ") #which looks like \n {temp2.head(3)}")

            if store_rev_blr_df.shape[0]==0:
                store_rev_blr_df = temp2.copy()
            else:
                store_rev_blr_df = store_rev_blr_df.merge(temp2, on = ['Month', 'Site Tenancy Classification', 'Operator'], how='left')

            # print(store_rev_blr_df.shape)
            # print(store_rev_blr_df.head(3))
            
        future_esc_blrs = pd.concat([future_esc_blrs, store_rev_blr_df], ignore_index=True)
        # print(f"shape of future_esc_blrs table after appending {i} data is {future_esc_blrs.shape} \n")

    ## filtering columns ahving escaltioin percent, cummulative escalations, and BLR values
    print(f"shape of final_future_esc_blrs table is {future_esc_blrs.shape} \n")
    not_req = [col for col in future_esc_blrs.columns if '__' in col]
    # print(not_req)
    final_cols = [col for col in future_esc_blrs.columns if col not in not_req and '_' in col and col.count('_') == 1]
    final_cols = ['Month', 'Site Tenancy Classification', 'Operator'] + final_cols
    print(len(final_cols))
    fltrd_future_esc_blrs = future_esc_blrs[final_cols]
    print(fltrd_future_esc_blrs.shape)

    ## calculating final future BLR
    blr_cols = [col for col in fltrd_future_esc_blrs.columns if '_EscBlr' in col]
    fltrd_future_esc_blrs['Base Lease Rate'] = fltrd_future_esc_blrs[blr_cols].sum(axis=1)
    # fltrd_future_esc_blrs.head(3)

    ## reading country-reg-tower_count mapping file
    cntry_reg_twrs = pd.read_excel('Country_Class_Region_NoT.xlsx', 'main')
    print(cntry_reg_twrs.shape)

    ## joining country-reg-tower_count mapping to find Revenue
    final_future_esc_blrs = fltrd_future_esc_blrs.merge(cntry_reg_twrs, on=['Site Tenancy Classification', 'Operator'],  how='left')
    print(final_future_esc_blrs.shape)
    final_future_esc_blrs['Revenue'] = final_future_esc_blrs['Base Lease Rate'] * final_future_esc_blrs['tower_count']
    # final_future_esc_blrs.head(5)

    return final_future_esc_blrs


def format_with_commas(value):
    if pd.notna(value) and isinstance(value, (int, float)):
        return '{:,.0f}'.format(value)
    else:
        return value