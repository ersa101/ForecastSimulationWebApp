import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
from functions import format_with_commas


def plot():
    st.title("Forecasting Results")

    # Plots
    
    # filter for operator
    op_options = ['All'] + list(st.session_state.final_future_esc_blrs.Operator.unique())
    operator = st.sidebar.selectbox("Select Operator:", op_options, key='operator')
    st.session_state.operator_name = operator

    if st.session_state.operator_name == 'All':
        op_fltrd = st.session_state.final_future_esc_blrs.copy()
    else:
        op_fltrd = st.session_state.final_future_esc_blrs[st.session_state.final_future_esc_blrs.Operator == st.session_state.operator_name]
    

    # filter for tenancy class 
    
    class_options = ['All'] + list(op_fltrd['Site Tenancy Classification'].unique())
    tenancy_class = st.sidebar.selectbox("Select Site Tenancy Class:", class_options, key='tenancy_class')

    if tenancy_class == 'All':
        class_fltrd = op_fltrd.copy()
    else:
        class_fltrd = op_fltrd[op_fltrd['Site Tenancy Classification'] == tenancy_class]


    # filter for Region
    
    reg_options = ['All'] + list(class_fltrd.Region.unique())
    reg = st.sidebar.selectbox("Select Site Region:", reg_options, key='reg')

    if reg == 'All':
        final_fltrd = class_fltrd.copy( )
    else:
        final_fltrd  = class_fltrd[class_fltrd.Region == reg]

    
    ## Buttons in the left sidebar
    # show_graph = st.sidebar.button("Show Graph 📈")
    # show_table = st.sidebar.button("Show Table 📅")
    st.sidebar.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
    download_button = st.sidebar.button("Download XLSX 📑")
    st.sidebar.markdown('<div style="margin-bottom:20px;"></div>', unsafe_allow_html=True)
    restart = st.sidebar.button("Start Again 🤯")


    ## filtering the contributing parameters in dropdown
    # not_int = ['Month', 'Site Tenancy Classification', 'Operator', 'Country', 'SAP Customer No', 'Region']
    # numeric_cols = list(set(final_fltrd.columns) - set(not_int))
    # final_fltrd[numeric_cols] = final_fltrd[numeric_cols].astype(int)
    # filtered_cols = final_fltrd.columns[final_fltrd[numeric_cols].min() != 0]
    # visua = final_fltrd[filtered_cols]


    # Plot_3
    st.markdown('<p style="color: seagreen; font-size: 28px; font-weight: bold;"> 1. Heat Map Trend Across Regions </p>', unsafe_allow_html=True)
    visua1 = final_fltrd[['Region', 'Month', 'tower_count', 'Revenue']]
    p1 = visua1.groupby('Region').agg({'Revenue':'sum', 'tower_count':'mean'}).reset_index()
    fig1 = px.scatter(p1, x='Revenue', y='tower_count', color='Region', size='Revenue', title='Scatter Plot by Region')
    # Customize the layout
    fig1.update_layout(
        xaxis_title='Revenue',
        yaxis_title='Tower Count',
        showlegend=False
    )

    # Display the chart using Streamlit
    st.plotly_chart(fig1)
    
    # Plot_1
    st.markdown('<p style="color: seagreen; font-size: 28px; font-weight: bold;"> 2. Base Lease Rate & Revenue Trend Across Months </p>', unsafe_allow_html=True)
    visua2 = final_fltrd[['Month', 'Base Lease Rate', 'Revenue']]
    p2 = visua2.groupby('Month')[['Base Lease Rate', 'Revenue']].sum().reset_index()
    fig2 = px.line(p2, x='Month', y=['Base Lease Rate', 'Revenue'], markers=True)
    fig2.update_layout( yaxis_title=None,  # Hide y-axis label
                        legend=dict(orientation='h', 
                                    yanchor='bottom', 
                                    y=-0.3, 
                                    xanchor='auto', 
                                    x=0.5),  # Show legend at the bottom
                    )
    st.plotly_chart(fig2)


    # Plot_3
    st.markdown('<p style="color: seagreen; font-size: 28px; font-weight: bold;"> 3. Escalation Trend Across Months </p>', unsafe_allow_html=True)
    colreq = [col for col in final_fltrd.columns if '_Cumm' in col]

    fig3 = go.Figure()
    for col in colreq:
        fig3.add_trace(go.Scatter(x=final_fltrd['Month'], y=final_fltrd[col], mode='lines', name=col))
    # Customize the layout
    fig3.update_layout(  xaxis_title='Month',
                        yaxis_title=None,
                        legend=dict(orientation='h', 
                                    yanchor='bottom', 
                                    y=-1.3, 
                                    xanchor='auto', 
                                    x=0.5)
                    )
    st.plotly_chart(fig3)

    
    
 


    
    
    

    # # Show Graph button
    # if show_graph:
    #     st.plotly_chart(fig)

    # # Show Table button
    # if show_table:
    #     st.dataframe(st.session_state.visua_grp)

    # Download XLSX button
    if download_button:
        st.success("Downloading your Compiled Data File ✌️✌️✌️")
        with pd.ExcelWriter(f"visua_allData_iter{int(round(st.session_state.iternum, 0))}.xlsx") as writer:
            st.session_state.parameters_df.to_excel(writer, sheet_name="conditional params", index=False)
            st.session_state.parameters_df2.to_excel(writer, sheet_name="base lease params", index=False)
            st.session_state.base.to_excel(writer, sheet_name="base", index=False)
            st.session_state.visua.applymap(format_with_commas).to_excel(writer, sheet_name="visua", index=False)
            st.session_state.visua_grp.applymap(format_with_commas).to_excel(writer, sheet_name="visua_grouped", index=False)
            st.session_state.visua_grp_perc.to_excel(writer, sheet_name="visua_grouped_perc", index=False)
            
    # Show Table button
    if restart:
        st.success("Taking you back to Initialization Screen 🔁🔁🔁")
        st.session_state.current_page = 'first'
        st.rerun()

# if __name__ == "__main__":
#     plot()
