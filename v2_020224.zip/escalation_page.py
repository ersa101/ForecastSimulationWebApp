import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
from functions import predata, baselease, esc, forecast_logic, format_with_commas


def escalation():
    
    st.title("Forecasting Input Dashboard : Escalation Parameters")

    # Initialize session_state if not present
    if 'input_esc' not in st.session_state:
        st.session_state.input_esc = pd.DataFrame(columns=['Operator', 'Site Tenancy Classification', 'Parameter', 'Start Month', 'Value', 'Escalation Frequency'])
    if 'chk_parameter_list' not in st.session_state:
        st.session_state.chk_parameter_list = []
    

    filtrd_latest_all_data = st.session_state.filtrd_latest_all_data

    # Get Conditional Contributing parameters input
    with st.sidebar.expander("Upload Escalation CSV file"):
        # parameter_name_options = ["Non Power Escalation", "Fuel Escalation", "Electrical Escalation", "FX"]
                                  
        country = st.sidebar.selectbox("Select Country:", st.session_state.ctry_op_sap_df.Country.unique(), key='country')
        st.session_state.country_name = country
        
        filtrd_latest_all_data = filtrd_latest_all_data[filtrd_latest_all_data.Country == st.session_state.country_name]
        operator = st.sidebar.selectbox("Select Operator:", filtrd_latest_all_data.Operator.unique(), key='operator')
        st.session_state.operator_name = operator
        
        filtrd_latest_all_data = filtrd_latest_all_data[filtrd_latest_all_data.Operator == st.session_state.operator_name]
        tenancy_class = st.sidebar.selectbox("Select Site Tenancy Class:", filtrd_latest_all_data['Site Tenancy Classification'].unique(), key='tenancy_class')
        
        # filtering the contributing parameters in dropdown
        esc_selected_class = filtrd_latest_all_data[filtrd_latest_all_data['Site Tenancy Classification'] == tenancy_class]
        esc_params = list(esc_selected_class.columns)
        req_cols = [cols for cols in filtrd_latest_all_data.columns if 'escmonthly__' in cols]
        esc_selected_class = esc_selected_class[req_cols]
        esc_params = [col.split('__')[1] for col in req_cols]
        # print(esc_params)
        col_rename_dict = dict(zip(esc_selected_class.columns, esc_params))
        esc_selected_class.rename(columns=col_rename_dict, inplace=True)
        filtered_cols = esc_selected_class.columns[esc_selected_class.min() != 0]
        esc_selected_class = esc_selected_class[filtered_cols]
        esc_parameters = [cols for cols in esc_selected_class.columns]
        print(esc_parameters)
        
        parameter_name = st.sidebar.selectbox("Select parameter name:", esc_parameters, key='parameter_name')
                                  
        parameter_start_month = st.sidebar.text_input("Enter start month for parameter (MM/YYYY):", key='parameter_start_month')
                                  
        parameter_value = st.sidebar.number_input("Enter Escalation value:", key='parameter_value')
                                  
        parameter_frequency_options = ["Monthly", "Quarterly", "Bi-Annual", "Annual"]
        parameter_frequency = st.sidebar.selectbox("Select parameter frequency:", parameter_frequency_options, key='parameter_frequency')
        
        # Display a "Save Changes" button
        st.sidebar.markdown('<div style="margin-bottom:10px;"></div>', unsafe_allow_html=True)
        save_changes = st.sidebar.button("Save/Upload Conditional Parameter")

        # Append the parameter to the DataFrame when "Save Changes" is clicked
        if save_changes:
            new_parameter = {'Operator' : operator, 'Site Tenancy Classification' : tenancy_class,
                             'Parameter': parameter_name, 'Start Month': parameter_start_month, 
                             'Value': parameter_value, 'Escalation Frequency': parameter_frequency}
            chk_parameter = operator + tenancy_class + parameter_name + str(parameter_start_month) 
            print(chk_parameter)
            
            if (len(parameter_start_month) != 7) & (chk_parameter not in st.session_state.chk_parameter_list):
                st.session_state.input_esc = pd.concat([st.session_state.input_esc, pd.DataFrame([new_parameter])], ignore_index=True)
                st.sidebar.success("Input parameter added Successfully ✅ ")
            elif (len(parameter_start_month) != 7) & (chk_parameter in st.session_state.chk_parameter_list):
                st.sidebar.error("Input parameter is Already Present ❌ ")
            else:
                st.sidebar.error("Input parameter is incomplete ❌ ")
                
        
        # File uploader for CSV
        st.sidebar.markdown('<div style="margin-bottom:10px;"></div>', unsafe_allow_html=True)
        uploaded_esc = st.file_uploader("Upload Escalation CSV file", type=["csv"], label_visibility='hidden')
        if uploaded_esc is not None:
            uploaded_esc = pd.read_csv(uploaded_esc)
            print(uploaded_esc)
            print(uploaded_esc.shape)
            st.session_state.input_esc = pd.concat([st.session_state.input_esc, uploaded_esc], ignore_index=True)
    
    # Display the latest BLRs
    for i in range(esc_selected_class.shape[1]):
        st.write(f"Latest Base Lease Rate for <span style='color: blue; font-size: 17px; font-weight: bold;'>{esc_selected_class.columns[i]}</span>  is   <span style='color: blue; font-size: 17px; font-weight: bold;'>{round(esc_selected_class.iloc[0, i],2)}%</span>", unsafe_allow_html=True)

    # Display the updated DataFrame
    st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
    # st.write("Conditional Contributional / Escalation Parameters")
    st.markdown('<p style="color: black; font-size: 28px; font-weight: bold;"> Conditional Contributional / Escalation Parameters </p>', unsafe_allow_html=True)
    print(st.session_state.input_esc)
    st.session_state.input_esc.drop_duplicates(inplace = True)
    st.session_state.input_esc['chk_parameters'] = st.session_state.input_esc.Operator.astype(str) + st.session_state.input_esc['Site Tenancy Classification'].astype(str) + st.session_state.input_esc.Parameter.astype(str) +  st.session_state.input_esc['Start Month'].astype(str)
    st.session_state.chk_parameter_list = st.session_state.input_esc.chk_parameters.unique()
    st.session_state.input_esc = st.session_state.input_esc[['Operator', 'Site Tenancy Classification', 'Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
    st.write(st.session_state.input_esc)
    
    
    # Display the sum of all final rates
    st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
    cols = st.columns([1,5,1])
    # with cols[1]:
    #     if st.button("Input Addon Parameters & Discount"):
    #         st.success("Let's add additional Parameters & Discounts➡️➡️➡️ ")
    #         # st.session_state.input_esc = st.session_state.input_esc[['Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
    #         st.session_state.current_page = 'addon'
    #         st.rerun()               
    
    with cols[1]:
        if st.button("Forecast Now 🧮"):
            st.success("Moving you to Forecast ➡️➡️➡️ ")
            st.write(f"Performing forecast for {st.session_state.forecast_duration} months starting from {st.session_state.start_month}")
            # st.session_state.input_esc = st.session_state.input_esc[['Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
            # Run the Simulations
            final_future_esc_blrs = forecast_logic(st.session_state.input_esc, st.session_state.input_blr, 
                                                   st.session_state.start_month, st.session_state.forecast_duration)
            st.session_state.final_future_esc_blrs = final_future_esc_blrs
            
            # print("forecast R*C is ", visua.shape, "\n", visua.columns, "\n")
            # visua_grp, visua_grp_perc = grouped_dwnld_excel(visua, st.session_state.grouping_frequency)
            # print(visua_grp.shape, "and grouped is ", visua_grp_perc.shape, "\n")

            # st.session_state.input_esc['Start Month'] = pd.to_datetime(st.session_state.input_esc['Start Month'])
            # st.session_state.input_esc['Start Month'] = st.session_state.input_esc['Start Month'].dt.strftime('%B-%y')
            # st.session_state.parameters_df2['Change Months'] = pd.to_datetime(st.session_state.parameters_df2['Change Months'])
            # st.session_state.parameters_df2['Change Months'] = st.session_state.parameters_df2['Change Months'].dt.strftime('%B-%y')

            # st.session_state.visua = visua
            # st.session_state.base = base
            # st.session_state.plot_col = plot_col
            # st.session_state.visua_grp = visua_grp
            # st.session_state.visua_grp_perc = visua_grp_perc
                        
            # with pd.ExcelWriter(f"visua_allData_iter{int(round(st.session_state.iternum, 0))}.xlsx") as writer:
            #     st.session_state.input_esc.to_excel(writer, sheet_name = "conditional params", index=False)
            #     st.session_state.parameters_df2.to_excel(writer, sheet_name = "base lease params", index=False)
            #     st.session_state.base.to_excel(writer, sheet_name = "base", index=False)
            #     st.session_state.visua.applymap(format_with_commas).to_excel(writer, sheet_name = "visua", index=False)
            #     st.session_state.visua_grp.applymap(format_with_commas).to_excel(writer, sheet_name = "visua_grouped", index=False)
            #     st.session_state.visua_grp_perc.to_excel(writer, sheet_name = "visua_grouped_perc", index=False)

            st.session_state.current_page = 'plot'
            st.rerun()

# if __name__ == "__main__":
#     escalation()
