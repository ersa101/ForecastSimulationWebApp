import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Define session state outside of main function
if 'start_month' not in st.session_state:
    st.session_state.start_month = "01/2024"
if 'forecast_duration' not in st.session_state:
    st.session_state.forecast_duration = 36
if 'grouping_frequency' not in st.session_state:
    st.session_state.grouping_frequency = "Monthly"
if 'iternum' not in st.session_state:
    st.session_state.iternum = 0
    
def initial():
    st.title("Forecasting Input Dashboard : Initial Parameters")

    # ## Country-Operator-SAP_ID mapping
    # ctry_op_sap = {'Country' : ['Tanzania', 'Tanzania', 'Malawi'],
    #                'Operator' : ['Viettel', 'Tigo', 'Airtel'],
    #                'SAP Customer No' : ['C4.V00001', 'C4.M00001', 'C11.A00003']}
    # ctry_op_sap_df = pd.DataFrame(ctry_op_sap)
    # st.session_state.ctry_op_sap_df = ctry_op_sap_df

    # country = st.selectbox("Select Country:", ctry_op_sap_df.Country.unique(), key='country')
    
    # operator = st.selectbox("Select Operator:", ctry_op_sap_df.Operator.unique(), key='operator')
    
    start_month = st.text_input("Enter start month for forecast (MM/YYYY):", "02/2024")
    
    forecast_duration = st.number_input("Enter the number of months for forecast:", min_value=1, value=36)
    
    grouping_frequency_options = ["Monthly", "Quarterly", "Bi-Annual", "Annual"]
    grouping_interval = st.selectbox("Select grouping frequency:", grouping_frequency_options, key='grouping_interval')
    
    # iternum = st.number_input("Enter the attempt number:", min_value = 1)

    # Save inputs to session
    # st.session_state.country_name = country
    # st.session_state.operator_name = operator
    st.session_state.start_month = start_month
    st.session_state.forecast_duration = forecast_duration
    st.session_state.grouping_frequency = grouping_interval
    # st.session_state.iternum = iternum

           
    # Display the sum of all final rates
    st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
    cols = st.columns([1,6,1])
    with cols[1]:
        if st.button("Input Baselease Rates"):
            st.success("Taking you to change Bse Lease Rates ➡️➡️➡️ ")
            st.session_state.current_page = 'baselease'
            st.rerun()               
    

# if __name__ == "__main__":
#     initial()
