import streamlit as st
import pandas as pd
import numpy as np
import re
import datetime as dt
from dateutil.relativedelta import relativedelta
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import plotly.subplots as sp
from functions import predata, baselease, esc, forecast_logic, linechart_dataframe, format_with_commas, forecast_period
import warnings

# Hide warnings
warnings.filterwarnings("ignore")
# st.set_page_config(page_title="Let's Play Forecast", page_icon="sstl_icon.jpg",  layout="wide", initial_sidebar_state="auto"  # 'auto', 'expanded', 'collapsed'
#                    )

def baselease_escalation():

    # st.title("Change Future Values for Lease Rates of Components")
    try:

        st.set_page_config(page_title="Let's Play Forecast", page_icon="sstl_icon.jpg",  layout="wide", initial_sidebar_state="auto" )

        ## Country-Operator-SAP_ID mapping
        ctry_op_sap = {'Country' : ['Tanzania', 'Tanzania', 'Malawi'],
                    'Operator' : ['Viettel', 'Tigo', 'Airtel'],
                    'SAP Customer No' : ['C4.V00001', 'C4.M00001', 'C11.A00003']}
        ctry_op_sap_df = pd.DataFrame(ctry_op_sap)
        st.session_state.ctry_op_sap_df = ctry_op_sap_df
        
        # Reading CSV having complete historical data for ESC, CFV, BLR
        latest_all_data = pd.read_excel('prev_data.xlsx')
        filtrd_latest_all_data = latest_all_data.merge(st.session_state.ctry_op_sap_df, on = 'SAP Customer No', how = 'inner')
        st.session_state.filtrd_latest_all_data = filtrd_latest_all_data

        # Reading CSV having predicted data for ESC, BLR
        pred_df = pd.read_csv('Baseline_visua_160224_125013.csv')
        pred_df['Month'] = pd.to_datetime(pred_df['Month'])

        # Country - Region - Tower Count
        st.session_state.cntry_reg_twrs = pd.read_excel('Country_Class_Region_NoT.xlsx', 'main')


        # Initialize session_state if not present
        if 'input_blr' not in st.session_state:
            st.session_state.input_blr = pd.DataFrame(columns=['Operator', 'Site Tenancy Classification', 'Month','Change Parameter', 'Base Rate'])
        if 'input_esc' not in st.session_state:
            st.session_state.input_esc = pd.DataFrame(columns=['Operator', 'Site Tenancy Classification', 'Parameter', 'Month', 'Value', 'Escalation Frequency'])
        if 'input_disc' not in st.session_state:
            st.session_state.input_disc = pd.DataFrame(columns=['Operator', 'Month'])   #, 'Discount Period'])
        if 'chk_parameter_list' not in st.session_state:
            st.session_state.chk_parameter_list = []
        if 'floor_ceil_caps' not in st.session_state:
            st.session_state.floor_ceil_caps = pd.read_csv('floor_ceil.csv')
        if 'plot_userdata' not in st.session_state:
            st.session_state.plot_userdata = pd.DataFrame()
        if 'plot_preddata' not in st.session_state:
            st.session_state.plot_preddata = pd.DataFrame()
        if 'forecast' not in st.session_state:
            st.session_state.forecast = False
        if 'hist_period' not in st.session_state:
            st.session_state.hist_period = 1
        if 'blr_selected_class' not in st.session_state:
            st.session_state.blr_selected_class = pd.DataFrame()
        if 'esc_selected_class' not in st.session_state:
            st.session_state.esc_selected_class = pd.DataFrame()
        if 'sap_cust_nmbr' not in st.session_state:
            st.session_state.sap_cust_nmbr = ''
        if 'hist_blr_esc_cfv_master' not in st.session_state:
            st.session_state.hist_blr_esc_cfv_master = pd.DataFrame()
        if 'final_future_esc_blrs' not in st.session_state:
            st.session_state.final_future_esc_blrs = pd.DataFrame()
        if 'disc_start_dt' not in st.session_state:
            st.session_state.disc_start_dt = '0'
        if 'uploaded_discslab' not in  st.session_state:
            st.session_state.uploaded_discslab = pd.DataFrame()
        
        

        # Get Base Lease parameters input 
        start_month = dt.datetime.now().strftime('%m/%Y')
        st.sidebar.write(f"<span style='color: darkblue; font-size: 17px; font-weight: bold;'>Start Month for forecast as per latest data is  </span> <span style='color: darkorange; font-size: 20px; font-weight: bold;'> {pd.to_datetime(start_month).strftime('%b-%Y')} </span> ", unsafe_allow_html=True)
        
        forecast_duration = st.sidebar.number_input("Enter the number of months for forecasting", min_value=12, value=36)
        if (int(forecast_duration) > 120) :
            st.sidebar.error("Enter Correct Forecasting Period")
        
        # Save inputs to session state
        st.session_state.start_month = start_month
        st.session_state.forecast_duration = forecast_duration
        st.session_state.months = forecast_period(st.session_state.start_month, st.session_state.forecast_duration)
        st.sidebar.write(f"<span style='color: black; font-size: 15px; '> Forecast till  </span> <span style='color: darkorange; font-size: 20px; font-weight: bold;'> {pd.to_datetime(st.session_state.months.months.max()).strftime('%b-%Y')} </span> ", unsafe_allow_html=True)

        
        if st.session_state.forecast == False:
            st.sidebar.markdown('<div style="margin-bottom:50px;"></div>', unsafe_allow_html=True)
            st.sidebar.write(f"<span style='color: darkblue; font-size: 17px; font-weight: bold;'> Change Input Parameters </span>", unsafe_allow_html=True)
            
            # dropdown for COUNTRY & OPERATOR
            cols = st.sidebar.columns([4,4])
            with cols[0]:
                country = st.selectbox("Select Country:", st.session_state.ctry_op_sap_df.Country.unique(), key='country')
                st.session_state.country_name = country
            with cols[1]:
                filtrd_latest_all_data = filtrd_latest_all_data[filtrd_latest_all_data.Country == st.session_state.country_name]
                operator = st.selectbox("Select Operator:", filtrd_latest_all_data.Operator.unique(), key='operator')
                st.session_state.operator_name = operator
            
            # dropdown for SITE TENANCY CLASS
            filtrd_latest_all_data = filtrd_latest_all_data[filtrd_latest_all_data.Operator == st.session_state.operator_name]
            tenancy_class = st.sidebar.selectbox("Select Site Tenancy Class:", filtrd_latest_all_data['Site Tenancy Classification'].unique(), key='tenancy_class')
                    
            # filtering the CONTRIBUTING PARAMETERS for dropdown
            selected_class = filtrd_latest_all_data[filtrd_latest_all_data['Site Tenancy Classification'] == tenancy_class]
            sap_cust_nmbr = selected_class['SAP Customer No'].min()
            print(f"sap_cust_nmbr is {sap_cust_nmbr}")

            blr_cols = [cols for cols in filtrd_latest_all_data.columns if 'blr__' in cols]
            blr_selected_class = selected_class[blr_cols]
            blr_params = [col.split('__')[3] for col in blr_cols]
            # print(blr_params)
            col_rename_dict = dict(zip(blr_selected_class.columns, blr_params))
            blr_selected_class.rename(columns=col_rename_dict, inplace=True)
            filtered_cols = blr_selected_class.columns[blr_selected_class.min() > 0]
            blr_selected_class = blr_selected_class[filtered_cols]

            latest_esc_table = pd.read_excel("EscalationIndex.xlsx", "Sheet1")
            latest_esc_table = latest_esc_table[latest_esc_table['SAP_Customer_No'] == sap_cust_nmbr][["Benchmark_index_of_escalation", "Benchmark index % change", "Month"]]
            latest_esc_table = latest_esc_table.sort_values(['Benchmark_index_of_escalation', 'Month'], ascending=[True, False])
            latest_indices = latest_esc_table.groupby('Benchmark_index_of_escalation')['Month'].idxmax()
            latest_esc_table = latest_esc_table.loc[latest_indices]
    
            st.session_state.sap_cust_nmbr = sap_cust_nmbr
            st.session_state.blr_selected_class = blr_selected_class
            st.session_state.esc_selected_class = latest_esc_table  ## esc_selected_class

            # dropdown for COMPONENT
            # parameter_name = st.sidebar.selectbox("Select Lease Rate Component:", esc_parameters, key='parameter_name')
            parameter_name = st.sidebar.selectbox("Select Lease Rate Component:", latest_esc_table.Benchmark_index_of_escalation.unique(), key='parameter_name')


            # dropdown for CHANGE TYPE
            change_parameters = ["Please Select Change Action", "Change Future Base Lease Rates", "Change Future Escalations", "Change Future Discounts"]    #  "Change Future Additional Parameters",
            change_name = st.sidebar.selectbox("Select Change action to be performed", change_parameters, key='change_name')

            # dropdown for USER INPUT as per the CHANGE selected
            if change_name == "Change Future Base Lease Rates":
                with st.sidebar.expander(':orange[**Input Future Base Lease Rates Here**]'):
                    ## input Change month
                    parameter_change_month = st.text_input("Effective Month of change (MM/YYYY):", key='parameter_change_month')
                    if len(parameter_change_month) == 7:
                        try:
                            parameter_change_month = (pd.to_datetime(parameter_change_month)).strftime('%b-%y')
                            print(f"bep.2: {parameter_change_month}")
                            if (pd.to_datetime(parameter_change_month, format='%b-%y') >= pd.to_datetime(st.session_state.months.months.min())) and  (pd.to_datetime(parameter_change_month, format='%b-%y') <= pd.to_datetime(st.session_state.months.months.max())):
                                st.success(f"Desired change will be effective from {parameter_change_month}")
                            else:
                                st.error("Month for Sought Change is INCORRECT or out of forecasting period")
                        except Exception as e:
                            print(f"bep.3: {e}")
                            st.error("Please Enter Correct Date")
                    
                    ## Input new BLR value
                    parameter_baselease_value = st.number_input("Enter New Base Lease value:", key='parameter_baselease_value')

                    ## File uploader option
                    st.markdown('<p style="color: darkblue; font-size: 20px; font-weight: bold; text-align: center; "> OR </p> <p style="color: darkblue; font-size: 15px;"> Download Input Tempalate CSV file from right pane </p>', unsafe_allow_html=True)
                    uploaded_baselease = st.file_uploader("", type=["csv"], label_visibility='hidden')
                    if uploaded_baselease is not None:
                        uploaded_blr = pd.read_csv(uploaded_baselease)
                        uploaded_blr['len'] = uploaded_blr['Month'].astype(str).apply(len)
                        print(f"bep.4: Shape is {uploaded_blr.shape} which looks like \n {uploaded_blr}")
                        if (uploaded_blr.len.nunique()) == 1:
                            # print(f"bep.4: Uploaded Data has shape {uploaded_blr.shape}")
                            uploaded_blr['Month'] = (pd.to_datetime(uploaded_blr['Month'])).dt.strftime('%b-%y')
                            uploaded_blr['key'] = uploaded_blr['Operator'] + uploaded_blr['Site Tenancy Classification'] + uploaded_blr['Month'] + uploaded_blr['Change Parameter']
                            new_uploads = list(set(uploaded_blr['key']) - set(st.session_state.key_list))
                            uploaded_blr_rev = uploaded_blr[uploaded_blr.key.isin(new_uploads)]
                            uploaded_blr_rev = uploaded_blr_rev.drop('key', axis=1)
                            print(f"bep.5: revised Upload BLR data has shape {uploaded_blr_rev.shape}")
                            st.session_state.input_blr = pd.concat([st.session_state.input_blr, uploaded_blr_rev], ignore_index=True)
                        else:
                            st.error("Something WRONG with Date Format in Base Lease Rate Input File 😵‍💫")

            elif change_name == "Change Future Escalations":
                with st.sidebar.expander(':orange[**Input Future Escalation Values Here**]'):
                    ## input Change month
                    parameter_start_month = st.text_input("Enter Effective start month (MM/YYYY):", key='parameter_start_month')
                    if len(parameter_start_month) == 7:
                        try:
                            parameter_start_month = (pd.to_datetime(parameter_start_month)).strftime('%b-%y')
                            print(f"bep.6: {parameter_start_month}")
                            if (pd.to_datetime(parameter_start_month, format='%b-%y') >= pd.to_datetime(st.session_state.months.months.min())) and  (pd.to_datetime(parameter_start_month, format='%b-%y') <= pd.to_datetime(st.session_state.months.months.max())):
                                st.success(f"Desired change will be effective from {parameter_start_month}")
                                st.session_state.pred_dt = pd.to_datetime(parameter_start_month, format='%b-%y')
                                print(f"bep.7: {st.session_state.pred_dt}")
                            else:
                                st.error("Month for Sought Change is INCORRECT or out of forecasting period")
                        except Exception as e:
                            print(f"bep.8: {e}")
                            st.error("Please Enter Correct Date")
                                            
                    ## input new ESC value
                    parameter_value = st.number_input("Enter Escalation value:", key='parameter_value')
                    pred_col = [col for col in pred_df.columns if ('_MonthlyPerc' in col) and (col.startswith(parameter_name))]
                    print(f"bep.9: col name for sought parameter is {pred_col[0]}   wherein other filters are {country}__{operator}__{tenancy_class}")
                    if 'pred_dt' in st.session_state:
                        pred_esc_val = round(pred_df[(pred_df.Country == country) & (pred_df.Operator == operator) & (pred_df['Site Tenancy Classification'] == tenancy_class) & (pred_df.Month == st.session_state.pred_dt)][pred_col[0]].min(),4)
                        print(f"bep.10: {pred_esc_val}")
                        st.write(f"<span style='color: red; font-size: 15px;'> Safe Predicted Value is  {pred_esc_val} </span> ", unsafe_allow_html=True)

                    ## select Frequency of escalation
                    parameter_frequency_options = ["Monthly", "Quarterly", "Bi-Annual", "Annual"]
                    parameter_frequency = st.selectbox("Select parameter frequency:", parameter_frequency_options, key='parameter_frequency')

                    ## File uploader option
                    st.markdown('<p style="color: darkblue; font-size: 20px; font-weight: bold; text-align: center; "> OR </p> <p style="color: darkblue; font-size: 15px;"> Download Input Tempalate CSV file from right pane </p>', unsafe_allow_html=True)
                    uploaded_esc = st.file_uploader("OR Upload Escalation CSV file", type=["csv"], label_visibility='hidden')
                    if uploaded_esc is not None:
                        uploaded_esc = pd.read_csv(uploaded_esc)
                        uploaded_esc['len'] = uploaded_esc['Month'].astype(str).apply(len)
                        print(f"bep.11: Shape is {uploaded_esc.shape} which looks like \n {uploaded_esc}")
                        if (uploaded_esc.len.nunique()) == 1:
                            uploaded_esc['Month'] = pd.to_datetime(uploaded_esc['Month']).dt.strftime('%b-%Y')
                            uploaded_esc['chk_parameters'] = uploaded_esc.Operator.astype(str) + uploaded_esc['Site Tenancy Classification'].astype(str) + uploaded_esc.Parameter.astype(str) +  uploaded_esc['Month'].astype(str)
                            #  Avoiding Duplicates while repeated run
                            new_uploads = list(set(uploaded_esc['chk_parameters']) - set(st.session_state.chk_parameter_list))
                            uploaded_esc_rev = uploaded_esc[uploaded_esc.chk_parameters.isin(new_uploads)]
                            uploaded_esc_rev = uploaded_esc_rev.drop('chk_parameters', axis=1)
                            # checking for Floor_Ceil values
                            if st.session_state.floor_ceil_caps.shape[0]>0:
                                temp = uploaded_esc_rev.merge(st.session_state.floor_ceil_caps, on = ['Site Tenancy Classification', 'Parameter'], how = 'left')
                                temp['UserValue'] = temp.Value
                                print(f"bep.12: {temp}")
                                temp['Value'] = np.where(temp['Value'] > temp['Escalation_cap'],
                                                                        (temp['Escalation_cap'] * temp['Escalation_multiplier'] / 100),
                                                                        np.where(temp['Value'] > temp['Escalation_floor'],
                                                                                (temp['Value'] * temp['Escalation_multiplier'] / 100),
                                                                                np.where(((temp['Value'] != 0)) & (temp['Value'] < temp['Escalation_floor']),
                                                                                            (temp['Escalation_floor'] * temp['Escalation_multiplier'] / 100),
                                                                                            temp['Value']
                                                                                        )
                                                                                )
                                                                    )
                                uploaded_esc_rev = temp[['Operator', 'Site Tenancy Classification', 'Parameter', 'Month', 'Value', 'Escalation Frequency']]
                                print(f"bep.13: Floor Ceil cap logic executed")
                            print(f"bep.14: revised Upload ESC data has shape {uploaded_esc_rev.shape}")
                            st.session_state.input_esc = pd.concat([st.session_state.input_esc, uploaded_esc_rev], ignore_index=True)
                        else:
                            st.error("Something WRONG with Date Format in Escalation Input File 😵‍💫")
                
            # elif change_name == "Change Future Additional Parameters":
            #     st.sidebar.success("WIP")
                            
            elif change_name == "Change Future Discounts":
                # st.sidebar.success("WIP")
                with st.sidebar.expander(':orange[**Input Future Discount Values Here**]'):
                    st.markdown('<p style="color: darkblue; font-size: 15px;"> Discount is applicable on OPERATOR, not on individual Tenancy Classes </p>', unsafe_allow_html=True)
                    
                    ## input Change month
                    discount_start_month = st.text_input("Enter Effective start month (MM/YYYY):", key='discount_start_month')

                    # ## select period of discount
                    # disc_period = st.number_input("Enter Discount Period:", key='disc_period', min_value = 1, step=1)

                    if len(discount_start_month) == 7:
                        try:
                            discount_start_month = (pd.to_datetime(discount_start_month)).strftime('%b-%y')
                            print(f"bep.8a: {discount_start_month}")
                            if (pd.to_datetime(discount_start_month, format='%b-%y') >= pd.to_datetime(st.session_state.months.months.min())) and (pd.to_datetime(discount_start_month, format='%b-%y') <= pd.to_datetime(st.session_state.months.months.max())):
                                # if disc_period > 2:
                                #     st.success(f'Desired change will be effective from {discount_start_month} to {(pd.to_datetime(discount_start_month, format="%b-%y") - relativedelta(months = disc_period - 1)).strftime("%b-%y")}')
                                #     st.session_state.disc_start_dt = pd.to_datetime(discount_start_month, format='%b-%y')     ## change 
                                #     print(f"bep.7: {st.session_state.disc_start_dt}")
                                # else: 
                                #     st.success(f'Desired change will be effective only for {discount_start_month}')
                                #     st.session_state.disc_start_dt = pd.to_datetime(discount_start_month, format='%b-%y')     ## change 
                                #     print(f"bep.7a: {st.session_state.disc_start_dt}")
                                st.success(f"Desired change will be effective from {discount_start_month} to {pd.to_datetime(st.session_state.months.months.max()).strftime('%b-%y')}")
                                # st.session_state.disc_start_dt = pd.to_datetime(discount_start_month, format='%b-%y')     ## change 
                                # print(f"bep.8b: {st.session_state.disc_start_dt}")
                            else:
                                st.error("Month for Sought Change is INCORRECT or out of forecasting period")
                        except Exception as e:
                            print(f"bep.8c: {e}")
                            st.error("Please Enter Correct Date")                                       
                
                    ## File uploader option
                    # st.markdown('<p style="color: darkblue; font-size: 15px;"> Download Input Tempalate CSV file from right pane </p>', unsafe_allow_html=True)
                    uploaded_discs = st.file_uploader("Upload Discount Slab CSV file", type=["csv"])
                    if uploaded_discs is not None:
                        uploaded_discs = pd.read_csv(uploaded_discs)
                        # uploaded_discslab['len'] = uploaded_discslab['Month'].astype(str).apply(len)
                        print(f"bep.8: Shape is {uploaded_discs.shape} which looks like \n {uploaded_discs}")
                        if st.session_state.uploaded_discslab.shape[0] == 0:
                            st.session_state.uploaded_discslab = pd.concat([st.session_state.uploaded_discslab, uploaded_discs])


            # Display a "Save Changes" button
            st.sidebar.markdown('<div style="margin-bottom:10px;"></div>', unsafe_allow_html=True)
            cols = st.sidebar.columns([1,4,1])
            with cols[1]:
                save_changes = st.button("Save Input Changes")

            # Append the parameter to the DataFrame when "Save Changes" is clicked
            if save_changes:
                if change_name == "Change Future Base Lease Rates":
                    if re.compile(r'^[a-zA-Z]{3}-\d{2}$').match(parameter_change_month):
                        baselease_parameter = {'Operator': [operator],
                                                'Site Tenancy Classification': [tenancy_class],
                                                'Month': [parameter_change_month],
                                                'Change Parameter': [parameter_name],
                                                'Base Rate': [parameter_baselease_value]
                                            }

                        baselease_changes = pd.DataFrame(baselease_parameter)
                        
                        baselease_changes['key'] = baselease_changes['Operator'] + baselease_changes['Site Tenancy Classification'] + baselease_changes['Month'] + baselease_changes['Change Parameter']
                        print(f"bl.3: {baselease_changes['key'].iloc[0]}")

                        if (len(parameter_change_month) == 6) and (baselease_changes['key'].iloc[0] in list(st.session_state.key_list)):
                            st.sidebar.error("Entry already in Database !")
                        elif (len(parameter_change_month) == 6) and (baselease_changes['key'].iloc[0] not in list(st.session_state.key_list)):
                            baselease_changes = baselease_changes.drop('key', axis=1)
                            st.session_state.input_blr = pd.concat([st.session_state.input_blr, baselease_changes], ignore_index=True)
                            st.sidebar.success("Input parameter added Successfully ✅ ")
                    else:
                        st.sidebar.error("Input parameter is incomplete ❌ ")

                elif change_name == "Change Future Escalations":
                    new_parameter = {'Operator' : operator, 'Site Tenancy Classification' : tenancy_class,
                                    'Parameter': parameter_name, 'Month': parameter_start_month, 
                                    'Value': parameter_value, 'Escalation Frequency': parameter_frequency}
                    chk_parameter = operator + tenancy_class + parameter_name + parameter_start_month
                    print(chk_parameter, chk_parameter not in st.session_state.chk_parameter_list)
                    user_esc = pd.DataFrame([new_parameter])
                    
                    if (len(parameter_start_month) == 6) and (chk_parameter not in st.session_state.chk_parameter_list) and (re.compile(r'^[a-zA-Z]{3}-\d{2}$').match(parameter_start_month)):
                        if st.session_state.floor_ceil_caps.shape[0]>0:
                            temp = user_esc.merge(st.session_state.floor_ceil_caps, on = ['Site Tenancy Classification', 'Parameter'], how = 'left')
                            temp['UserValue'] = temp.Value
                            print(f"bep.15: {temp}")
                            temp['Value'] = np.where(temp['Value'] > temp['Escalation_cap'],
                                                                (temp['Escalation_cap'] * temp['Escalation_multiplier'] / 100),
                                                                np.where(temp['Value'] > temp['Escalation_floor'],
                                                                            (temp['Value'] * temp['Escalation_multiplier'] / 100),
                                                                            np.where(((temp['Value'] != 0)) & (temp['Value'] < temp['Escalation_floor']),
                                                                                    (temp['Escalation_floor'] * temp['Escalation_multiplier'] / 100),
                                                                                    temp['Value']
                                                                                    )
                                                                            )
                                                                )
                            temp = temp[['Operator', 'Site Tenancy Classification', 'Parameter', 'Month', 'Value', 'Escalation Frequency']]
                        st.session_state.input_esc = pd.concat([st.session_state.input_esc, temp], ignore_index=True)
                        st.sidebar.success("Input parameter added Successfully ✅ ")
                    elif (len(parameter_start_month) == 6) and (chk_parameter in st.session_state.chk_parameter_list):
                        st.sidebar.error("Input parameter is Already Present ❌ ")
                    else:
                        st.sidebar.error("Input parameter is incomplete 😵‍💫 Check input Date format")

                # elif change_name == "Change Future Additional Parameters":
                #     st.sidebar.success("WIP")
                        
                elif change_name == "Change Future Discounts":
                    # st.sidebar.success("WIP")

                    if re.compile(r'^[a-zA-Z]{3}-\d{2}$').match(discount_start_month):
                        new_disc_entry = {'Operator' : [operator], 'Month': [discount_start_month]} # , 'Discount Period': [disc_period]}
                        new_disc_entry_df = pd.DataFrame(new_disc_entry)
                        
                        #  -----------------         if discount tenure is ALSO to be used in calculations then  uncomment the below commented section    -------------
                        # new_disc_entry_df['key'] = new_disc_entry_df['Operator'] + new_disc_entry_df['Month']
                        # print(f"bep.15a: {new_disc_entry_df['key'].iloc[0]}")
                        # st.session_state.input_disc['key'] = st.session_state.input_disc['Operator'] + st.session_state.input_disc['Month']
                        # disc_key_list = st.session_state.input_disc.key.unique()

                        # if (len(discount_start_month) == 6) and (new_disc_entry_df['key'].iloc[0] in disc_key_list):
                        #     st.sidebar.error("Entry already in Database !")
                        # elif (len(discount_start_month) == 6) and (new_disc_entry_df['key'].iloc[0] not in disc_key_list):
                        #     new_disc_entry_df = new_disc_entry_df.drop('key', axis=1)
                        #     st.session_state.input_disc = st.session_state.input_disc.drop('key', axis=1)


                        if (len(discount_start_month) == 6) and (operator in st.session_state.input_disc.Operator.unique()):
                            st.sidebar.error("Operator Discount already in Database !")
                        elif (len(discount_start_month) == 6) and (operator not in st.session_state.input_disc.Operator.unique()):

                            st.session_state.input_disc = pd.concat([st.session_state.input_disc, new_disc_entry_df], ignore_index=True)
                            print(f"bep.15b: {st.session_state.input_disc}")
                            st.sidebar.success("Input parameter added Successfully ✅ ")
                    else:
                        st.sidebar.error("Input parameter is incomplete ❌ ")

                else:
                    st.sidebar.error("Input parameter is not selected !! ")
                    

                
        # Display the latest BLRs
        st.markdown('<p style="color: darkblue; font-size: 32px; font-weight: bold;"> Latest Rates & Escalation Percentages of Components </p>', unsafe_allow_html=True)
        latest_df_ui = pd.DataFrame(columns = ['Component', 'Escalated Rate', 'Latest Escalation Value', 'Lastest Escalation Month'])
        for i in st.session_state.esc_selected_class.Benchmark_index_of_escalation.unique():
            if i in st.session_state.blr_selected_class.columns:
                blr_val = st.session_state.blr_selected_class[i].min()
                esc_val = st.session_state.esc_selected_class[st.session_state.esc_selected_class.Benchmark_index_of_escalation==i][["Benchmark index % change"]].min().min()
                esc_mnth = st.session_state.esc_selected_class[st.session_state.esc_selected_class.Benchmark_index_of_escalation==i]["Month"].min()
                esc_mnth = pd.to_datetime(esc_mnth).strftime('%B %Y')
                # st.write(f"Rate for Component <span style='color: darkblue; font-size: 17px; font-weight: bold;'>{i}</span>  is   <span style='color: darkorange; font-size: 17px; font-weight: bold;'>{'{:,}'.format(int(blr_val))} </span> as on <span style='color: darkblue; font-size: 17px;'>{(dt.datetime.now()-relativedelta(months=1)).strftime('%B %Y')}</span> with Escalation Value as <span style='color: darkorange; font-size: 17px; font-weight: bold;'>{round(esc_val,2)}%</span> changed on <span style='color: darkblue; font-size: 17px;'>{esc_mnth}</span>", unsafe_allow_html=True)
                latest_df_dict = {'Component': [i], 'Escalated Rate': ['{:,}'.format(int(blr_val))], 'Latest Escalation Value': [round(esc_val,2)], 'Lastest Escalation Month' : [esc_mnth]}
                latest_df_ui = pd.concat([latest_df_ui, pd.DataFrame(latest_df_dict)], ignore_index=True)
            else:
                # st.write(f"Mismatch observed between the Escalation Value and Lease Rate of Components")
                print(st.session_state.sap_cust_nmbr)
                print(st.session_state.blr_selected_class)
                print(st.session_state.esc_selected_class)
        st.write(latest_df_ui)


        # Displaying the updated Dataframes for all future changes input by user
        ## Updated DataFrame for future BLR changes
        st.session_state.input_blr.drop_duplicates(inplace = True)
        st.session_state.input_blr['key'] = st.session_state.input_blr['Operator'] + st.session_state.input_blr['Site Tenancy Classification'] + st.session_state.input_blr['Month'] + st.session_state.input_blr['Change Parameter']
        st.session_state.key_list = st.session_state.input_blr.key.unique()
        print(f"bep.15: {st.session_state.key_list}")
        st.session_state.input_blr = st.session_state.input_blr[['Operator', 'Site Tenancy Classification', 'Month', 'Change Parameter', 'Base Rate']]
        # st.write(st.session_state.input_blr)
        print(f"bep.16: input_blr has shape of {st.session_state.input_blr.shape} and looks like \n {st.session_state.input_blr}")

        ## Updated DataFrame for future ESC changes
        print(f"bep.17: {st.session_state.input_esc}")
        st.session_state.input_esc.drop_duplicates(inplace = True)
        st.session_state.input_esc['chk_parameters'] = st.session_state.input_esc.Operator.astype(str) + st.session_state.input_esc['Site Tenancy Classification'].astype(str) + st.session_state.input_esc.Parameter.astype(str) +  st.session_state.input_esc['Month'].astype(str)

        st.session_state.chk_parameter_list = list(st.session_state.input_esc.chk_parameters.unique())
        print(f"bep.18: {st.session_state.chk_parameter_list}")

        st.session_state.input_esc = st.session_state.input_esc[['Operator', 'Site Tenancy Classification', 'Parameter', 'Month', 'Value', 'Escalation Frequency']]
        # st.write(st.session_state.input_esc)
        print(f"bep.19: input_esc has shape of {st.session_state.input_esc.shape} and looks like \n {st.session_state.input_esc}")

        ## Display the TEMPALATES   AND   USER FED CHANGES
        st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
        st.markdown('<p style="color: darkblue; font-size: 28px; font-weight: bold;"> User Input Change Tables </p>', unsafe_allow_html=True)
        st.markdown('<p style="color: darkblue; font-size: 15px; "> Download these templates / Tables by clicking on download button (⬇️) from Top Right Corner of Table. </p>', unsafe_allow_html=True)
        with st.expander(':orange[Expand to Download **Input TEMPLATES**]'):
            st.markdown('<p style="color: darkblue; font-size: 15px; font-style: italic;"> 1.  Posssible Tenancy Classses with their components are provided in the sheet. </br> 2.  Using ONLY these classes & components, prepare a datasheet as per the desired future change. </br> 3.  The change sought will be effective from the month as mentioned by user till the forecast end month unless another same change is sought in another month. </p>', unsafe_allow_html=True)
            cols = st.columns([2,4,4,4,2])
            with cols[1]:
                tempalate_base_lease_rate_button = st.button('Base Lease Rate')
            with cols[2]:
                tempalate_escalations_button = st.button('Escalations')
            with cols[3]:
                tempalate_discslab_button = st.button('Discount Slab')
            
            if tempalate_base_lease_rate_button:
                st.markdown('<p style="color: orange; font-size: 14px; text-style:bold; "> Template for Base Lease Rate Components </p>', unsafe_allow_html=True)
                blr_template = (pd.read_excel('userInputTempalate.xlsx', 'input_blr'))
                blr_template['Month'] = pd.to_datetime(blr_template['Month']).dt.strftime('%b-%Y')
                st.write(blr_template)
            elif tempalate_escalations_button:
                st.markdown('<p style="color: orange; font-size: 14px; text-style:bold;"> Template for Escalations of Lease Rate Components </p>', unsafe_allow_html=True)
                esc_template = (pd.read_excel('userInputTempalate.xlsx', 'input_esc'))
                esc_template['Month'] = pd.to_datetime(esc_template['Month']).dt.strftime('%b-%Y')
                st.write(esc_template)
            elif tempalate_discslab_button:
                st.markdown('<p style="color: orange; font-size: 14px; font-style: bold; "> Template for Tower count based slab for Discount Percentage </p>', unsafe_allow_html=True)
                discslab_template = pd.DataFrame(columns=['Slab', 'Lower Tower count', 'Upper Tower Count', 'Discount Percentage Value'])
                for slab in range(1, 8):
                    discslab_template = pd.concat([discslab_template, pd.DataFrame({'Slab': [slab], 'Lower Tower count': [None], 'Upper Tower Count': [None], 'Discount Percentage Value': [None]})], ignore_index=True)
                st.write(discslab_template)

        
        with st.expander(':orange[Expand to View & Download **USER INPUT DATA**]'):
        # with st.expander('<span style="color: teal; font-size: 28px; font-weight: bold;"> Download User Input and Final Output Tables </span>', unsafe_allow_html=True):
            cols = st.columns([4,4,4,4])
            with cols[0]:
                user_base_lease_rate_button = st.button('Base Lease Rate Input')
            with cols[1]:
                user_escalations_button = st.button('Escalations Input')
            with cols[2]:
                user_discmonthperiod_button = st.button('Discount Month')    # & Period Input')
            with cols[3]:
                user_discslab_button = st.button('Discount Slabs Input')
    
            if user_base_lease_rate_button:
                st.markdown('<p style="color: purple; font-size: 15px; font-weight: bold;"> User Input Base Lease Rate Components </p>', unsafe_allow_html=True)
                if st.session_state.input_blr.shape[0] > 0:
                    st.write(st.session_state.input_blr)
                else:
                    st.write("No Change in Future Base Lease Rate Component")
            if user_escalations_button:
                st.markdown('<p style="color: purple; font-size: 15px; font-weight: bold;"> User Input Escalations of Components </p>', unsafe_allow_html=True)
                if st.session_state.input_esc.shape[0] > 0:
                    st.write(st.session_state.input_esc)
                else:
                    st.write("No Change in Future Escalations of Lease Rate Component")
            if user_discslab_button:
                st.markdown('<p style="color: purple; font-size: 15px; font-weight: bold;"> User Input Discount Slab values </p>', unsafe_allow_html=True)
                if st.session_state.uploaded_discslab.shape[0] > 0:
                    st.session_state.uploaded_discslab = st.session_state.uploaded_discslab[~ st.session_state.uploaded_discslab['Discount Percentage Value'].isna()]
                    st.write(st.session_state.uploaded_discslab)
                else:
                    st.write("No Discount Slab Values received")
            if user_discmonthperiod_button :
                st.markdown('<p style="color: purple; font-size: 15px; font-weight: bold;"> User Input Discount Month for Selected Operator </p>', unsafe_allow_html=True)
                if st.session_state.input_disc.shape[0] > 0:
                    if 'key' in st.session_state.input_disc.columns:
                        st.session_state.input_disc = st.session_state.input_disc.drop('key', axis=1)
                    st.write(st.session_state.input_disc)
                else:
                    st.write("No Discount applied on the Operators")

        st.markdown('<div style="margin-bottom:60px;"></div>', unsafe_allow_html=True)
        
        
        # Move to Forecasting 
        st.sidebar.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
        cols = st.sidebar.columns([5,4])    
        with cols[0]:
            forecast = st.button("Forecast Now 🧮")
            if forecast:
                st.session_state.forecast = True
                st.success("Moving you to Forecast ➡️➡️➡️ ")
                st.write(f"Performing forecast for {st.session_state.forecast_duration} months starting from {st.session_state.start_month}")

                # Run the Simulations
                hist_blr_esc_cfv_master, final_future_esc_blrs, cntry_reg_twrs = forecast_logic(st.session_state.input_esc, st.session_state.input_blr, st.session_state.months, st.session_state.uploaded_discslab, st.session_state.input_disc)
                st.session_state.hist_blr_esc_cfv_master = hist_blr_esc_cfv_master
                st.session_state.final_future_esc_blrs = final_future_esc_blrs
                st.session_state.cntry_reg_twrs = cntry_reg_twrs
                
                st.session_state.time_identifier = dt.datetime.now().strftime('%d%m%Y_%H%M%S')                        
                with pd.ExcelWriter(f"OutputDataSimulatedPredicted_{st.session_state.username}_{st.session_state.time_identifier}.xlsx") as writer:
                    st.session_state.input_blr.to_excel(writer, sheet_name = "NewBLRs", index=False)
                    st.session_state.input_esc.to_excel(writer, sheet_name = "NewESCs", index=False)
                    st.session_state.final_future_esc_blrs.to_excel(writer, sheet_name = "SimulatedDataAll", index=False)
                
                # st.session_state.current_page = 'plot'
                # st.rerun() 
        
        with cols[1]:
            restart = st.button("Re-Run ♻️")
            if restart:
                st.session_state.forecast = False
                username = st.session_state.username
                st.session_state.clear()

                st.session_state.username = username
                st.success("Taking you back to Initialization Screen 🔁🔁🔁")
                st.session_state.current_page = 'blr_esc'
                st.rerun()
                # st.session_state.clear()

        # Display Plots
        if st.session_state.forecast == True:
            st.sidebar.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
            st.sidebar.write("<span style='color: darkblue; font-size: 17px; font-weight: bold;'> Change Graph Filters </span>", unsafe_allow_html=True)
            # Plot filters
            hist_period = st.sidebar.number_input("Enter Historical Period ", value=24)
            st.session_state.hist_period = hist_period
            # st.session_state.forecast = True
            print(f"bep.20: {type(hist_period)}, {hist_period}")

            req_hist_future_df = linechart_dataframe(st.session_state.hist_blr_esc_cfv_master, st.session_state.final_future_esc_blrs, st.session_state.cntry_reg_twrs, hist_period)
            st.session_state.req_hist_future_df = req_hist_future_df
            print(f"bep.20a: colnames of all future prediction dataframe is {req_hist_future_df.columns} which looks like \n {req_hist_future_df.head(5)}")

            baseline_hist_future_df = pd.read_csv('Baseline_visua_160224_125013.csv')
            baseline_hist_future_df['Month'] = pd.to_datetime(baseline_hist_future_df['Month'])
            baseline_hist_future_df['Discount'] = 0
            baseline_hist_future_df.drop(['pk_SAP_SiteTenantClass'], axis=1, inplace=True)
            # print(baseline_hist_future_df['Month'].unique())
            print(f"bep.21: min forecast month is {st.session_state.months.months.min()} \n max forecast month is {st.session_state.months.months.max()}")
            st.session_state.baseline_hist_future_df = baseline_hist_future_df[baseline_hist_future_df.Month <= st.session_state.months.months.max()]
            st.session_state.baseline_hist_future_df = st.session_state.baseline_hist_future_df[st.session_state.baseline_hist_future_df.Month >= (st.session_state.months.months.min() - pd.DateOffset(months=int(hist_period)))]

            print(f"bep.22: colnames are {st.session_state.baseline_hist_future_df.columns} which looks like \n {st.session_state.baseline_hist_future_df.shape}")

            # filter for operator
            if (st.session_state.input_blr.shape[0] > 0) or (st.session_state.input_esc.shape[0] > 0):
                op_options = list(set(st.session_state.input_blr.Operator.unique()) or set(st.session_state.input_esc.Operator.unique()))
            else:
                op_options = ['All']
            operator_nm = st.sidebar.selectbox("Select Operator:", op_options, key='operator_nm')
            st.session_state.plot_operator_name = operator_nm
            if st.session_state.plot_operator_name == 'All':
                # st.session_state.forecast = True
                op_fltrd = st.session_state.req_hist_future_df.copy()
                op_fltrd_baseline = st.session_state.baseline_hist_future_df.copy()
            else:
                # st.session_state.forecast = True
                op_fltrd = st.session_state.req_hist_future_df[st.session_state.req_hist_future_df.Operator == st.session_state.plot_operator_name]
                op_fltrd_baseline = st.session_state.baseline_hist_future_df[st.session_state.baseline_hist_future_df.Operator == st.session_state.plot_operator_name]
            
            # filter for tenancy class
            if (st.session_state.input_blr.shape[0] > 0) or (st.session_state.input_esc.shape[0] > 0):
                class_options = list(set(st.session_state.input_blr['Site Tenancy Classification'].unique()) or set(st.session_state.input_esc['Site Tenancy Classification'].unique()))
            else:
                class_options = ['All'] 
            plot_tenancy_class = st.sidebar.selectbox("Select Site Tenancy Class:", class_options, key='plot_tenancy_class')
            if plot_tenancy_class == 'All':
                # st.session_state.forecast = True
                class_fltrd = op_fltrd.copy()
                class_fltrd_baseline = op_fltrd_baseline.copy()
            else:
                # st.session_state.forecast = True
                class_fltrd = op_fltrd[op_fltrd['Site Tenancy Classification'] == plot_tenancy_class]
                class_fltrd_baseline = op_fltrd_baseline[op_fltrd_baseline['Site Tenancy Classification'] == plot_tenancy_class]


            # filter for Region
            reg_options = ['All'] + list(class_fltrd.Region.unique())
            reg = st.sidebar.selectbox("Select Site Region:", reg_options, key='reg')
            if reg == 'All':
                # st.session_state.forecast = True
                final_fltrd = class_fltrd.copy( )
                final_fltrd_baseline = class_fltrd_baseline.copy()
            else:
                # st.session_state.forecast = True
                final_fltrd  = class_fltrd[class_fltrd.Region == reg]
                final_fltrd_baseline = class_fltrd_baseline[class_fltrd_baseline.Region == reg]


            ## filtering the contributing parameters in dropdown
            not_int = ['Month', 'Site Tenancy Classification', 'Operator', 'Country', 'SAP Customer No', 'Region']
            numeric_cols = list(set(final_fltrd.columns) - set(not_int))
            final_fltrd[numeric_cols] = final_fltrd[numeric_cols].astype('float64')
            average_values = final_fltrd[numeric_cols].mean().to_dict()
            zero_cols = [k for k,v in average_values.items() if v==0]
            plottable_cols = list(set(numeric_cols) - set(zero_cols))
            print(f"bep.23: {plottable_cols}")
            final_fltrd_cnvrtd = final_fltrd[not_int + plottable_cols]
            print(f"\n {numeric_cols} \n")

            # numeric_cols_baseline = list(set(final_fltrd_baseline.columns) - set(not_int))
            final_fltrd_baseline[numeric_cols] = final_fltrd_baseline[numeric_cols].astype('float64')
            average_values_baseline = final_fltrd_baseline[numeric_cols].mean().to_dict()
            zero_cols_baseline = [k for k,v in average_values_baseline.items() if v==0]
            plottable_cols_baseline = list(set(numeric_cols) - set(zero_cols_baseline))
            print(f"bep.24: {plottable_cols_baseline}")
            final_fltrd_cnvrtd_baseline = final_fltrd_baseline[not_int + plottable_cols_baseline]

            print(f"bep.25: {final_fltrd_cnvrtd.shape}, {final_fltrd_cnvrtd_baseline.shape}") 

            st.session_state.plot_userdata = final_fltrd_cnvrtd
            st.session_state.plot_preddata = final_fltrd_cnvrtd_baseline

            # st.sidebar.markdown('<div style="margin-bottom:60px;"></div>', unsafe_allow_html=True)
        
        # Plot Logic
        if st.session_state.plot_userdata.shape[0] > 0 :

            ## Plot_1
            st.markdown('<p style="color: darkblue; font-size: 28px; font-weight: bold;"> 1. Revenue Heat Map Trend Across Regions </p>', unsafe_allow_html=True)
            st.markdown('<p style="color: darkorange; font-size: 18px; "> Total revenue of forecasting period ditributed across Regions with respect to number of towers in that region </p>', unsafe_allow_html=True)

            if (st.session_state.input_blr.shape[0] > 0) or (st.session_state.input_esc.shape[0] > 0):
                visua1_fix = st.session_state.req_hist_future_df[st.session_state.req_hist_future_df.Month >= st.session_state.start_month]
                visua1_fix['Region'] = visua1_fix['Region'].astype(str)
                visua1_fix = visua1_fix.groupby(['Region', 'Month', 'tower_count']).agg({'Revenue':'sum'}).reset_index()
                p1_fix = visua1_fix.groupby(['Region', 'Month']).agg({'Revenue':'sum', 'tower_count':'sum'}).reset_index()
                print(f"bep.26: p1_fix colnames are {p1_fix.columns} which looks like \n {p1_fix.sort_values(['Region', 'Month']).head(50)}")
                # print(f"{p1_fix.Region.value_counts()}")
                # print(f"{p1_fix[p1_fix.Region == 'Dar es Salaam']}")
                # p1_fix.to_csv('plot_Not.csv', index=False)
                p1_fix = p1_fix.groupby('Region').agg({'Revenue': 'sum', 'tower_count': 'mean'}).reset_index()
                # print(f"{p1_fix[p1_fix.Region == 'Dar es Salaam']}")
                fig1_fix = px.scatter(p1_fix, x='Revenue', y='tower_count', color='Region', size='tower_count') #, title='Scatter Plot by Region')

                visua1_filter = st.session_state.plot_userdata[['Region', 'Month', 'tower_count', 'Revenue']]
                visua1_filter = visua1_filter[visua1_filter.Month >= st.session_state.start_month]
                p1_filter = visua1_filter.groupby('Region').agg({'Revenue':'sum', 'tower_count':'mean'}).reset_index()
                fig1_filter = px.scatter(p1_filter, x='Revenue', y='tower_count', color='Region', size='Revenue') #, title='Scatter Plot by Region')
                
                fig1 = sp.make_subplots(rows=1, cols=2, subplot_titles=['All Operator : All Class : All Region', f'{st.session_state.plot_operator_name} Operator : {plot_tenancy_class} Class : {reg} Region'])
                for trace in fig1_fix['data']:
                    fig1.add_trace(trace, row=1, col=1)
                for trace in fig1_filter['data']:
                    fig1.add_trace(trace, row=1, col=2)
                fig1.update_layout(height=500, width=1000, showlegend=False, margin=dict(t=100),
                                xaxis1=dict(tickfont=dict(size=15, color='black')),
                                xaxis2=dict(tickfont=dict(size=15, color='black')),
                                yaxis1=dict(title=dict(text='Tower Count', standoff=40, font=dict(size=18, color='black')), tickfont=dict(size=15, color='black')),
                                yaxis2=dict(tickfont=dict(size=15, color='black'), range=[0, 80]) )
                st.plotly_chart(fig1)
                st.markdown('<p style="color: black; font-size: 18px; text-align: center; "> Overall Forecasted Revenue </p>', unsafe_allow_html=True)
            else:
                visua1_filter = st.session_state.plot_userdata[['Region', 'Month', 'tower_count', 'Revenue']]
                visua1_filter = visua1_filter[visua1_filter.Month >= st.session_state.start_month]
                p1_filter = visua1_filter.groupby('Region').agg({'Revenue':'sum', 'tower_count':'mean'}).reset_index()
                fig1_filter = px.scatter(p1_filter, x='Revenue', y='tower_count', color='Region', size='Revenue') #, title='Scatter Plot by Region')
                
                fig1_filter.update_layout(height=500, width=1000, showlegend=False, margin=dict(t=100),
                                xaxis1=dict(title=dict(text='Revenue', standoff=40, font=dict(size=18, color='black')), tickfont=dict(size=15, color='black')),
                                yaxis1=dict(title=dict(text='Tower Count', standoff=40, font=dict(size=18, color='black')), tickfont=dict(size=15, color='black')),
                                )
                st.plotly_chart(fig1_filter)

        

            
            ## Plot_2
            st.markdown('<div style="margin-bottom:50px;"></div>', unsafe_allow_html=True)
                    
            # Filter table data	
            visua_all = st.session_state.req_hist_future_df.drop_duplicates()
            visua_all['Region'] = visua_all['Region'].astype(str)
            visua_all = visua_all[['Month', 'Base Lease Rate', 'Revenue']]
            visua_predAll = st.session_state.baseline_hist_future_df[['Month', 'Base Lease Rate', 'Revenue']]
            visua_user = st.session_state.plot_userdata[['Month', 'Base Lease Rate', 'Revenue']]
            visua_predfltrd = st.session_state.plot_preddata[['Month', 'Base Lease Rate', 'Revenue']]

            ### Group and aggregate data for both DataFrames
            plot_all = visua_all.groupby('Month')[['Base Lease Rate', 'Revenue']].sum().reset_index()
            plot_predAll = visua_predAll.groupby('Month')[['Base Lease Rate', 'Revenue']].sum().reset_index()
            plot_user = visua_user.groupby('Month')[['Base Lease Rate', 'Revenue']].sum().reset_index()
            plot_pred = visua_predfltrd.groupby('Month')[['Base Lease Rate', 'Revenue']].sum().reset_index()
            plot_pred.rename(columns={'Base Lease Rate':'Predicted - BaseLeaseRate', 'Revenue':'Predicted - Revenue'}, inplace=True)

            ### Create REVENUE line plots
            fig2_Rev_allRev = px.line(plot_all, x='Month', y='Revenue', markers=True)
            fig2_Rev_predRevAllRev = px.line(plot_predAll, x='Month', y='Revenue', markers=False)
            fig2_Rev_userRev = px.line(plot_user, x='Month', y='Revenue', markers=True)
            fig2_Rev_predRev = px.line(plot_pred, x='Month', y='Predicted - Revenue', markers=False)


            ### Update layout for the FILTERED User & Preds chart
            fig2_Rev_userRev.update_traces(marker=dict(size=4.5))
            fig2_Rev_predRev.update_traces(line=dict(dash='dash'))
            #### Add traces from the second plot to the first one
            for trace in fig2_Rev_predRev.data:
                fig2_Rev_userRev.add_trace(trace)

            ### Update layout for the ALL User & Preds chart
            fig2_Rev_allRev.update_traces(marker=dict(size=4.5))
            fig2_Rev_predRevAllRev.update_traces(line=dict(dash='dash'))
            #### Add traces from the second plot to the first one
            for trace in fig2_Rev_predRevAllRev.data:
                fig2_Rev_allRev.add_trace(trace)

            #### Show the combined plot
            st.markdown('<p style="color: darkblue; font-size: 28px; font-weight: bold;"> 2. Revenue & Base Lease Rate Trend Across Months </p>', unsafe_allow_html=True)
            st.markdown('<p style="color: darkorange; font-size: 18px; text-align:center; "> Revenue across forecasting Months </p>', unsafe_allow_html=True)

            if (st.session_state.input_blr.shape[0] > 0) or (st.session_state.input_esc.shape[0] > 0):
                fig2_Rev = sp.make_subplots(rows=1, cols=2, subplot_titles=['All Operator : All Class : All Region', f'{st.session_state.plot_operator_name} Operator : {plot_tenancy_class} Class : {reg} Region'])
                for trace in fig2_Rev_allRev['data']:
                    fig2_Rev.add_trace(trace, row=1, col=1)
                for trace in fig2_Rev_userRev['data']:
                    fig2_Rev.add_trace(trace, row=1, col=2)
                fig2_Rev.update_layout(height=500, width=1000, showlegend=False, margin=dict(t=100),
                                xaxis1=dict(tickfont=dict(size=15, color='black')),
                                xaxis2=dict(tickfont=dict(size=15, color='black')),
                                yaxis1=dict(title=dict(text='Revenue', standoff=40, font=dict(size=18, color='black')), tickfont=dict(size=15, color='black')),
                                yaxis2=dict(tickfont=dict(size=15, color='black')) )
                #### Add vertical line for start_month
                fig2_Rev.add_shape(dict(type='line',
                                        x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                        y0=(plot_user.Revenue.min())*0.99, y1=(plot_all.Revenue.max())*1.01,
                                        line=dict(color='red', width=1),
                                    ), row=1, col=1)
                fig2_Rev.add_shape(dict(type='line',
                                        x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                        y0=(plot_user.Revenue.min())*0.99, y1=(plot_all.Revenue.max())*1.01,
                                        line=dict(color='red', width=1),
                                    ), row=1, col=2)
                st.plotly_chart(fig2_Rev)
            else:
                fig2_Rev_userRev.update_layout(height=500, width=1000, showlegend=True, margin=dict(t=100),
                                xaxis1=dict(title=dict(text='', standoff=40, font=dict(size=15, color='black')), tickfont=dict(size=15, color='black')),
                                yaxis1=dict(title=dict(text='Revenue', standoff=40, font=dict(size=18, color='black')), tickfont=dict(size=15, color='black')),
                                )
                #### Add vertical line for start_month
                fig2_Rev_userRev.add_shape(dict(type='line',
                                            x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                            y0=(plot_user.Revenue.min())*0.99, y1=(plot_all.Revenue.max())*1.01,
                                            line=dict(color='red', width=1),
                                            ))
                st.plotly_chart(fig2_Rev_userRev)
            
            
            
            st.markdown('<div style="margin-bottom:20px;"></div>', unsafe_allow_html=True)
            
            ### Create BASE LEASE RATE line plots
            fig2_allBLR = px.line(plot_all, x='Month', y='Base Lease Rate', markers=True)
            fig2_predAllBLR = px.line(plot_predAll, x='Month', y='Base Lease Rate', markers=False)
            fig2_userBLR = px.line(plot_user, x='Month', y='Base Lease Rate', markers=True)
            fig2_predBLR = px.line(plot_pred, x='Month', y='Predicted - BaseLeaseRate', markers=False)

            ### Update layout for the FILTERED User & Preds chart
            fig2_userBLR.update_traces(marker=dict(size=4.5))
            fig2_predBLR.update_traces(line=dict(dash='dash'))
            #### Add traces from the second plot to the first one
            for trace in fig2_predBLR.data:
                fig2_userBLR.add_trace(trace)

            ### Update layout for the ALL User & Preds chart
            fig2_allBLR.update_traces(marker=dict(size=4.5))
            fig2_predAllBLR.update_traces(line=dict(dash='dashdot'))
            #### Add traces from the second plot to the first one
            for trace in fig2_predAllBLR.data:
                fig2_allBLR.add_trace(trace)
        

            #### Show the combined plot
            st.markdown('<p style="color: darkorange; font-size: 18px;  text-align:center; "> Base Lease Rates across forecasting Months </p>', unsafe_allow_html=True)

            if (st.session_state.input_blr.shape[0] > 0) or (st.session_state.input_esc.shape[0] > 0):
                fig2_BLR = sp.make_subplots(rows=1, cols=2, subplot_titles=['All Operator : All Class : All Region', f'{st.session_state.plot_operator_name} Operator : {plot_tenancy_class} Class : {reg} Region'])
                for trace in fig2_allBLR['data']:
                    fig2_BLR.add_trace(trace, row=1, col=1)
                for trace in fig2_userBLR['data']:
                    fig2_BLR.add_trace(trace, row=1, col=2)
                fig2_BLR.update_layout(height=500, width=1000, showlegend=True, margin=dict(t=100),
                                xaxis1=dict(tickfont=dict(size=15, color='black')),
                                xaxis2=dict(tickfont=dict(size=15, color='black')),
                                yaxis1=dict(title=dict(text='Base Lease Rate', standoff=40, font=dict(size=18, color='black')), tickfont=dict(size=15, color='black')),
                                yaxis2=dict(tickfont=dict(size=15, color='black')) )
                #### Add vertical line for start_month
                fig2_BLR.add_shape(dict(type='line',
                                        x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                        y0=(plot_user['Base Lease Rate'].min())*0.99, y1=(plot_all['Base Lease Rate'].max())*1.01, 
                                        line=dict(color='red', width=1),
                                    ), row=1, col=1)
                fig2_BLR.add_shape(dict(type='line',
                                        x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                        y0=(plot_user['Base Lease Rate'].min())*0.99, y1=(plot_all['Base Lease Rate'].max())*1.01, 
                                        line=dict(color='red', width=1),
                                    ), row=1, col=2)
                st.plotly_chart(fig2_BLR)
            else:
                fig2_userBLR.update_layout(height=500, width=1000, showlegend=False, margin=dict(t=100),
                                xaxis1=dict(title=dict(text='', standoff=40, font=dict(size=15, color='black')), tickfont=dict(size=15, color='black')),
                                yaxis1=dict(title=dict(text='Base Lease Rate', standoff=40, font=dict(size=18, color='black')), tickfont=dict(size=15, color='black')),
                                )
                #### Add vertical line for start_month
                fig2_userBLR.add_shape(dict(type='line',
                                        x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                        y0=(plot_user['Base Lease Rate'].min())*0.99, y1=(plot_all['Base Lease Rate'].max())*1.01, 
                                        line=dict(color='red', width=1),
                                    ))

                st.plotly_chart(fig2_userBLR)


            ## Plot_3
            st.markdown('<div style="margin-bottom:50px;"></div>', unsafe_allow_html=True)
            st.markdown('<p style="color: darkblue; font-size: 28px; font-weight: bold;"> 3. Escalation Trend Across Months </p>', unsafe_allow_html=True)
            st.markdown('<p style="color: darkorange; font-size: 18px; "> Escalation Values across forecasting Months </p>', unsafe_allow_html=True)

            colreq = [col for col in st.session_state.plot_userdata.columns if '_Cumm' in col]

            ### plot FILTER data
            st.session_state.plot_userdata['Table'] = 'UserFltrd'
            st.session_state.plot_preddata['Table'] = 'PredFltrd'
            combined_data_cumm = pd.concat([st.session_state.plot_userdata[['Month', 'Table'] + colreq], st.session_state.plot_preddata[['Month', 'Table'] + colreq]], ignore_index=True)

            monthly_averages_cumm = combined_data_cumm.groupby(['Month', 'Table'])[colreq].mean().reset_index()

            fig_combined_cumm = go.Figure()
            for col in colreq:
                for table in monthly_averages_cumm['Table'].unique():
                    table_data = monthly_averages_cumm[monthly_averages_cumm['Table'] == table]
                    mode = 'lines+markers' if table == 'UserFltrd' else 'lines'
                    line_dash = 'solid' if table == 'UserFltrd' else 'dash'
                    fig_combined_cumm.add_trace(go.Scatter(
                        x=table_data['Month'],
                        y=table_data[col],
                        mode=mode,
                        name=f"{table} - {col}",
                        marker_size=3,
                        line=dict(dash=line_dash)
                    ))
            

            ### plot ALL data
            visua2_all = st.session_state.req_hist_future_df.drop_duplicates()
            visua2_all['Table'] = 'UserAll'
            st.session_state.baseline_hist_future_df['Table'] = 'PredAll'
            combined_data_cumm_all = pd.concat([visua2_all[['Month', 'Table'] + colreq], st.session_state.baseline_hist_future_df[['Month', 'Table'] + colreq]], ignore_index=True)

            monthly_averages_cumm_all = combined_data_cumm_all.groupby(['Month', 'Table'])[colreq].mean().reset_index()

            fig_combined_cumm_all = go.Figure()
            for col in colreq:
                for table in monthly_averages_cumm_all['Table'].unique():
                    table_data = monthly_averages_cumm_all[monthly_averages_cumm_all['Table'] == table]
                    mode = 'lines+markers' if table == 'UserAll' else 'lines'
                    line_dash = 'solid' if table == 'UserAll' else 'dash'
                    fig_combined_cumm_all.add_trace(go.Scatter(
                        x=table_data['Month'],
                        y=table_data[col],
                        mode=mode,
                        name=f"{table} - {col}",
                        marker_size=3,
                        line=dict(dash=line_dash)
                    ))
        

            if (st.session_state.input_blr.shape[0] > 0) or (st.session_state.input_esc.shape[0] > 0):
                fig3 = sp.make_subplots(rows=1, cols=2, subplot_titles=['All Operator : All Class : All Region', f'{st.session_state.plot_operator_name} Operator : {plot_tenancy_class} Class : {reg} Region'])
                for trace in fig_combined_cumm_all['data']:
                    fig3.add_trace(trace, row=1, col=1)
                for trace in fig_combined_cumm['data']:
                    fig3.add_trace(trace, row=1, col=2)
            
                fig3.update_layout(height=500, width=1000, margin=dict(t=100), 
                                    xaxis = dict(title=dict(text='', standoff=40, font=dict(size=15, color='black')), tickfont=dict(size=15, color='black')),
                                    yaxis = dict(title=dict(text='Cummulative Values', standoff=40, font=dict(size=15, color='black')), tickfont=dict(size=15, color='black')), 
                                    legend=dict(orientation='h', yanchor='bottom', y=-0.8, xanchor='auto', x=0.5),
                                )

                #### Add vertical line for start_month
                fig3.add_shape(dict(type='line',
                                    x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                    y0=(monthly_averages_cumm_all[colreq].min().min())*0.9, y1=(monthly_averages_cumm_all[colreq].max().max())*1.1,
                                    line=dict(color='red', width=1),
                                    ), row=1, col=1)
                fig3.add_shape(dict(type='line',
                                    x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                    y0=(monthly_averages_cumm[colreq].min().min())*0.9, y1=(monthly_averages_cumm[colreq].max().max())*1.1,
                                    line=dict(color='red', width=1),
                                    ), row=1, col=2)
                st.plotly_chart(fig3)
            else:     
                fig_combined_cumm.update_layout(height=500, width=1000, margin=dict(t=100), 
                                                xaxis = dict(title=dict(text='', standoff=40, font=dict(size=15, color='black')), tickfont=dict(size=15, color='black')),
                                                yaxis = dict(title=dict(text='Cummulative Values', standoff=40, font=dict(size=15, color='black')), tickfont=dict(size=15, color='black')), 
                                                legend=dict(orientation='h', yanchor='bottom', y=-0.8, xanchor='auto', x=0.5) )

                #### Add vertical line for start_month
                fig_combined_cumm.add_shape(dict(type='line',
                                            x0=pd.to_datetime(st.session_state.start_month), x1=pd.to_datetime(st.session_state.start_month),
                                            y0=(monthly_averages_cumm_all[colreq].min().min())*0.9, y1=(monthly_averages_cumm_all[colreq].max().max())*1.1,
                                            line=dict(color='red', width=1),
                                            ))

                st.plotly_chart(fig_combined_cumm)




            ## Download SIMULATION OUTPUT Table
            st.markdown('<div style="margin-bottom:110px;"></div>', unsafe_allow_html=True)
            st.markdown('<p style="color: teal; font-size: 28px; font-weight: bold;"> Download Final Output Table </p>', unsafe_allow_html=True)
            with st.expander(':blue[**Expand to Download**]'):
                st.markdown('<p style="color: purple; font-size: 15px; font-weight: bold;"> Output Table for filtered data </p>', unsafe_allow_html=True)
                frstcols = ['Month', 'Country', 'Operator', 'SAP Customer No', 'Site Tenancy Classification', 'Region', 'tower_count', 'Base Lease Rate', 'Revenue']
                othercols = [col for col in st.session_state.plot_userdata.columns if (col not in frstcols) and (('_EscBlr' in col) or ('_MonthlyPerc' in col) or ('_CummPerc' in col))]
                
                show_table = st.session_state.plot_userdata[st.session_state.plot_userdata['Month'] >= (st.session_state.months.months.min() - pd.DateOffset(months=int(st.session_state.hist_period)))]
                show_table.fillna(0, inplace=True)
                show_table = show_table.reset_index(drop=True)
                show_table['Month'] = pd.to_datetime(show_table['Month']).dt.strftime('%b-%Y')
                show_table['Base Lease Rate'] = show_table['Base Lease Rate'].astype('int64')
                show_table['Revenue'] = show_table['Revenue'].astype('int64')
                st.write(show_table[frstcols + othercols])

        else:
            st.write("Plotted Graph displayed once forecasting algorithm cycle is complete")

    except Exception as e:
        print(f"MASSIVE ERROR OCCURRED as \n {e}")
        st.markdown("<h2 style='text-align: center;'>Server Error. Please refresh the page.</h2>", unsafe_allow_html=True)
