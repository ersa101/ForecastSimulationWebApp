import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from functions import forecast_period
import time

# Define session state outside of main function
# if 'start_month' not in st.session_state:
#     st.session_state.start_month = "01/2024"
# if 'forecast_duration' not in st.session_state:
#     st.session_state.forecast_duration = 36
# if 'grouping_frequency' not in st.session_state:
#     st.session_state.grouping_frequency = "Monthly"
# if 'iternum' not in st.session_state:
#     st.session_state.iternum = 0
if 'user' not in st.session_state:
    st.session_state.user = False

try:
    login_creds = pd.read_csv('login_creds.csv')
    print(f"Login Creds CSV has shape of {login_creds.shape}")
except Exception as e:
    print(e)


def login():
    try:

        # st.title("Login Page")
        st.markdown("<h1 style='text-align: center;'>Login Page</h1>", unsafe_allow_html=True)
        st.markdown('<div style="margin-bottom:30px;"></div>', unsafe_allow_html=True)
        cols = st.columns([3,10,3])
        with cols[1]:
            st.image("sstl.jpg",  use_column_width=True)


        st.markdown('<div style="margin-bottom:50px;"></div>', unsafe_allow_html=True)

        cols = st.columns([3,6,6,3])
        with cols[1]:
            username = st.text_input("Enter Username")
        with cols[2]:
            pswrd = st.text_input("Enter Password")
        st.markdown('<div style="margin-bottom:50px;"></div>', unsafe_allow_html=True)

        inputkey = username + "_" + pswrd

        st.session_state.username = username
        
        cols =  st.columns([3,15])
        with cols[1]:
            if st.button("Login"):
                if inputkey in login_creds.key.unique():
                    st.session_state.user = True
                    st.success("User Validated")
                    time.sleep(2)
                    st.session_state.current_page = 'blr_esc'
                    st.rerun()       
                else:
                    st.error("Invalid User Details")

    except Exception as e:
        print(f"MASSIVE ERROR OCCURRED as \n {e}")
        st.markdown("<h2 style='text-align: center;'>Server Error. Please refresh the page.</h2>", unsafe_allow_html=True)

