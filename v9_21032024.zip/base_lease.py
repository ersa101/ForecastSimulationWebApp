import streamlit as st
import pandas as pd
import numpy as np
import re
import datetime as dt
from dateutil.relativedelta import relativedelta
from functions import predata, baselease, format_with_commas, forecast_period

def baselease():

    st.title("Change Future Base Lease Rates of Components")

    ## Country-Operator-SAP_ID mapping
    ctry_op_sap = {'Country' : ['Tanzania', 'Tanzania', 'Malawi'],
                   'Operator' : ['Viettel', 'Tigo', 'Airtel'],
                   'SAP Customer No' : ['C4.V00001', 'C4.M00001', 'C11.A00003']}
    ctry_op_sap_df = pd.DataFrame(ctry_op_sap)
    st.session_state.ctry_op_sap_df = ctry_op_sap_df
    
    # Reading CSV having complete historical data for ESC, CFV, BLR
    latest_all_data = pd.read_excel('prev_data.xlsx')
    filtrd_latest_all_data = latest_all_data.merge(st.session_state.ctry_op_sap_df, on = 'SAP Customer No', how = 'inner')
    st.session_state.filtrd_latest_all_data = filtrd_latest_all_data


    # Initialize session_state if not present
    if 'input_blr' not in st.session_state:
        # st.session_state.input_blr = pd.DataFrame(columns=['Site Tenancy Classification', 'Month', 'Diesel', 'Electricity', 'NonPower'])
        st.session_state.input_blr = pd.DataFrame(columns=['Operator', 'Site Tenancy Classification', 'Month','Change Parameter', 'Base Rate'])

    # Get Base Lease parameters input 

    # st.sidebar.markdown('<div style="margin-bottom:100px;"></div>', unsafe_allow_html=True)
    start_month = dt.datetime.now().strftime('%m/%Y')
    # start_month = pd.to_datetime(start_month).strftime('%m/%Y')
    st.sidebar.write(f"<span style='color: darkgray; font-size: 17px; font-weight: bold;'>Start Month for forecast as per latest data is  </span> <span style='color: purple; font-size: 20px; font-weight: bold;'> {start_month} </span> ", unsafe_allow_html=True)
    
    forecast_duration = st.sidebar.number_input("Enter the number of months for forecast:", min_value=12, value=36)
    if (int(forecast_duration) > 108) :
        st.sidebar.error("Enter Correct Forecasting Period")
    

    # Save inputs to session
    st.session_state.start_month = start_month
    st.session_state.forecast_duration = forecast_duration
    st.session_state.months = forecast_period(st.session_state.start_month, st.session_state.forecast_duration)

    with st.sidebar.expander("Upload CSV file"):
        
        country = st.sidebar.selectbox("Select Country:", st.session_state.ctry_op_sap_df.Country.unique(), key='country')
        st.session_state.country_name = country
        
        filtrd_latest_all_data = filtrd_latest_all_data[filtrd_latest_all_data.Country == st.session_state.country_name]
        operator = st.sidebar.selectbox("Select Operator:", filtrd_latest_all_data.Operator.unique(), key='operator')
        st.session_state.operator_name = operator
        
        filtrd_latest_all_data = filtrd_latest_all_data[filtrd_latest_all_data.Operator == st.session_state.operator_name]
        tenancy_class = st.sidebar.selectbox("Select Site Tenancy Class:", filtrd_latest_all_data['Site Tenancy Classification'].unique(), key='tenancy_class')
               
        # filtering the contributing parameters in dropdown
        blr_selected_class = filtrd_latest_all_data[filtrd_latest_all_data['Site Tenancy Classification'] == tenancy_class]
        blr_params = list(blr_selected_class.columns)
        req_cols = [cols for cols in filtrd_latest_all_data.columns if 'blr__' in cols]
        blr_selected_class = blr_selected_class[req_cols]
        blr_params = [col.split('__')[3] for col in req_cols]
        # print(blr_params)
        col_rename_dict = dict(zip(blr_selected_class.columns, blr_params))
        blr_selected_class.rename(columns=col_rename_dict, inplace=True)
        filtered_cols = blr_selected_class.columns[blr_selected_class.min() > 0]
        blr_selected_class = blr_selected_class[filtered_cols]
        blr_parameters = [cols for cols in blr_selected_class.columns]
        parameter_name = st.sidebar.selectbox("Select Lease Rate Component:", blr_parameters, key='parameter_name')
        
        parameter_change_month = st.sidebar.text_input("Effective Change Month (MM/YYYY):", key='parameter_change_month')
        if len(parameter_change_month) == 7:
            try:
                parameter_change_month = (pd.to_datetime(parameter_change_month)).strftime('%b-%y')
                print(f"bl.1: {parameter_change_month}")
                if (pd.to_datetime(parameter_change_month, format='%b-%y') >= pd.to_datetime(st.session_state.months.months.min())) and  (pd.to_datetime(parameter_change_month, format='%b-%y') <= pd.to_datetime(st.session_state.months.months.max())):
                    st.sidebar.success("Month for Sought Change is CORRECT")
                else:
                    st.sidebar.error("Month for Sought Change is INCORRECT or out of forecasting period")
            except Exception as e:
                print(f"bl.2: {e}")
                st.error("Please Enter Correct Date")
        
        parameter_baselease_value = st.sidebar.number_input("Enter New Base Lease value:", key='parameter_baselease_value')
                
        # Display a "Save Changes" button
        st.sidebar.markdown('<div style="margin-bottom:10px;"></div>', unsafe_allow_html=True)
        save_changes = st.sidebar.button("Save Base Lease Changes")

        # Append the parameter to the DataFrame when "Save Changes" is clicked
        if save_changes:
            if re.compile(r'^[a-zA-Z]{3}-\d{2}$').match(parameter_change_month):
                baselease_parameter = {'Operator': [operator],
                                        'Site Tenancy Classification': [tenancy_class],
                                        'Month': [parameter_change_month],
                                        'Change Parameter': [parameter_name],
                                        'Base Rate': [parameter_baselease_value]
                                    }

                baselease_changes = pd.DataFrame(baselease_parameter)

                # choices = baselease_changes['Change Parameter'].unique()
                # baselease_changes_pivot = baselease_changes[['Site Tenancy Classification', 'Month']].copy()
                # for choice in ['Diesel', 'Electricity', 'NonPower']:
                #     if choice in choices:
                #         baselease_changes_pivot[choice] = float('nan')
                # for index, row in baselease_changes.iterrows():
                #     baselease_changes_pivot.loc[index, row['Change Parameter']] = row['Base Rate']
                
                baselease_changes['key'] = baselease_changes['Operator'] + baselease_changes['Site Tenancy Classification'] + baselease_changes['Month'] + baselease_changes['Change Parameter']
                print(f"bl.3: {baselease_changes['key'].iloc[0]}")

                if (len(parameter_change_month) == 6) and (baselease_changes['key'].iloc[0] in list(st.session_state.key_list)):
                    st.sidebar.error("Entry already in Database !")
                elif (len(parameter_change_month) == 6) and (baselease_changes['key'].iloc[0] not in list(st.session_state.key_list)):
                    baselease_changes = baselease_changes.drop('key', axis=1)
                    st.session_state.input_blr = pd.concat([st.session_state.input_blr, baselease_changes], ignore_index=True)
                    st.sidebar.success("Input parameter added Successfully ✅ ")
            else:
                st.sidebar.error("Input parameter is incomplete ❌ ")

        
        # File uploader for CSV
        # st.sidebar.markdown('<div style="margin-bottom:10px;"></div>', unsafe_allow_html=True)

        uploaded_baselease = st.file_uploader("Upload CSV file", type=["csv"], label_visibility='hidden')
        if uploaded_baselease is not None:
            uploaded_blr = pd.read_csv(uploaded_baselease)
            print(f"bl.4: Uploaded Data has shape {uploaded_blr.shape}")
            uploaded_blr['Month'] = (pd.to_datetime(uploaded_blr['Month'])).dt.strftime('%b-%y')
            uploaded_blr['key'] = uploaded_blr['Operator'] + uploaded_blr['Site Tenancy Classification'] + uploaded_blr['Month'] + uploaded_blr['Change Parameter']
            new_uploads = list(set(uploaded_blr['key']) - set(st.session_state.key_list))
            uploaded_blr_rev = uploaded_blr[uploaded_blr.key.isin(new_uploads)]
            uploaded_blr_rev = uploaded_blr_rev.drop('key', axis=1)
            print(f"bl.5: revised Upload BLR data has shape {uploaded_blr_rev.shape}")
            st.session_state.input_blr = pd.concat([st.session_state.input_blr, uploaded_blr_rev], ignore_index=True)
            
    # Display the latest BLRs
    for i in range(blr_selected_class.shape[1]):
        st.write(f"Latest Rate for Component <span style='color: blue; font-size: 17px; font-weight: bold;'>{blr_selected_class.columns[i]}</span>  is   <span style='color: blue; font-size: 17px; font-weight: bold;'>{int(blr_selected_class.iloc[0, i])} </span> updated in {(dt.datetime.now()-relativedelta(months=1)).strftime('%B %Y')}", unsafe_allow_html=True)


    # Display the updated DataFrame
    st.markdown('<div style="margin-bottom:20px;"></div>', unsafe_allow_html=True)
    st.markdown('<p style="color: black; font-size: 28px; font-weight: bold;"> User Input Base Lease Rate Changes</p>', unsafe_allow_html=True)
    st.session_state.input_blr.drop_duplicates(inplace = True)
    st.session_state.input_blr['key'] = st.session_state.input_blr['Operator'] + st.session_state.input_blr['Site Tenancy Classification'] + st.session_state.input_blr['Month'] + st.session_state.input_blr['Change Parameter']
    st.session_state.key_list = st.session_state.input_blr.key.unique()
    print(f"bl.6: {st.session_state.key_list}")
    st.session_state.input_blr = st.session_state.input_blr[['Operator', 'Site Tenancy Classification', 'Month','Change Parameter', 'Base Rate']]
    st.write(st.session_state.input_blr)
    print(f"bl.7: input_blr has shape of {st.session_state.input_blr.shape} and looks like \n {st.session_state.input_blr}")
    
    # Add some margin before the "Forecast Now" button
    st.markdown('<div style="margin-bottom:20px;"></div>', unsafe_allow_html=True)
    
    # Navigating to other pages
    cols = st.columns([1, 6, 1])
    with cols[1]:
        if st.button("Input Escalation Values"):
            st.success("Escalating You ➡️➡️➡️ ")
            st.session_state.current_page = 'esc'
            st.rerun()  
            
#         if st.button("Input Escalation Values"):
#             st.success("Escalating You ➡️➡️➡️ ")
#             st.write(f"Performing forecast for {st.session_state.forecast_duration} months starting from {st.session_state.start_month}")
#             st.session_state.parameters_df = st.session_state.parameters_df[['Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
            
#             # Run the Simulations
#             visua, base, plot_col = forecast_logic(st.session_state.parameters_df, st.session_state.start_month, 
#                                                    st.session_state.forecast_duration, st.session_state.input_blr)
#             print("forecast R*C is ", visua.shape, "\n", visua.columns, "\n")
#             visua_grp, visua_grp_perc = grouped_dwnld_excel(visua, st.session_state.grouping_frequency)
#             print(visua_grp.shape, "and grouped is ", visua_grp_perc.shape, "\n")
            
#             # Change the format of Date to be saved in dataframe >> CSV
#             st.session_state.parameters_df['Start Month'] = pd.to_datetime(st.session_state.parameters_df['Start Month'])
#             st.session_state.parameters_df['Start Month'] = st.session_state.parameters_df['Start Month'].dt.strftime('%B-%y')
#             st.session_state.input_blr['Change Months'] = pd.to_datetime(st.session_state.input_blr['Change Months'])
#             st.session_state.input_blr['Change Months'] = st.session_state.input_blr['Change Months'].dt.strftime('%B-%y')
            
#             st.session_state.visua = visua
#             st.session_state.base = base
#             st.session_state.plot_col = plot_col
#             st.session_state.visua_grp = visua_grp
#             st.session_state.visua_grp_perc = visua_grp_perc
            
#             # with pd.ExcelWriter(f"visua_allData_iter{int(round(st.session_state.iternum, 0))}.xlsx") as writer:
#             #     st.session_state.parameters_df.to_excel(writer, sheet_name="conditional params", index=False)
#             #     st.session_state.input_blr.to_excel(writer, sheet_name="base lease params", index=False)
#             #     st.session_state.base.to_excel(writer, sheet_name="base", index=False)
#             #     st.session_state.visua.applymap(format_with_commas).to_excel(writer, sheet_name="visua", index=False)
#             #     st.session_state.visua_grp.applymap(format_with_commas).to_excel(writer, sheet_name="visua_grouped", index=False)
#             #     st.session_state.visua_grp_perc.to_excel(writer, sheet_name="visua_grouped_perc", index=False)


#             st.session_state.current_page = 'plot'
#             st.rerun()

# if __name__ == "__main__":
#     baselease()
