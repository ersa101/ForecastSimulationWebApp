import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from functions import forecast_period
import time

# Define session state outside of main function
if 'start_month' not in st.session_state:
    st.session_state.start_month = "01/2024"
if 'forecast_duration' not in st.session_state:
    st.session_state.forecast_duration = 36
if 'grouping_frequency' not in st.session_state:
    st.session_state.grouping_frequency = "Monthly"
if 'iternum' not in st.session_state:
    st.session_state.iternum = 0
st.session_state.user = False

try:
    login_creds = pd.read_csv('login_creds.csv')
    print(f"Login Creds CSV has shape of {login_creds.shape}")
except Exception as e:
    print(e)
    
def login():

    # st.title("Login Page")
    st.markdown("<h1 style='text-align: center;'>Login Page</h1>", unsafe_allow_html=True)
    st.markdown('<div style="margin-bottom:30px;"></div>', unsafe_allow_html=True)
    st.image("sstl.jpg",  use_column_width=True)
    st.markdown('<div style="margin-bottom:50px;"></div>', unsafe_allow_html=True)

    username = st.text_input("Enter Username")
    pswrd = st.text_input("Enter Password")
    st.markdown('<div style="margin-bottom:50px;"></div>', unsafe_allow_html=True)

    inputkey = username + "_" + pswrd

    st.session_state.username = username
    
    cols =  st.columns([8,5,5])
    with cols[1]:
        if st.button("Login"):
            if inputkey in login_creds.key.unique():
                st.session_state.user = True
                st.success("User Validation Successfull")
                time.sleep(2)
                st.session_state.current_page = 'jump'
                st.rerun()       
            else:
                st.error("Invalid User Details")
    
    # st.markdown('<div style="margin-bottom:100px;"></div>', unsafe_allow_html=True)
    # start_month = dt.datetime.now().strftime('%m/%Y')
    # start_month = pd.to_datetime(start_month).strftime('%m/%Y')
    # st.write(f"<span style='color: darkgray; font-size: 17px; font-weight: bold;'>Start Month for forecast as per latest data is  </span> <span style='color: purple; font-size: 20px; font-weight: bold;'> {start_month} </span> ", unsafe_allow_html=True)

    # # start_month = st.text_input("Enter start month for forecast (MM/YYYY):", "02/2024")
    # # if pd.to_datetime(start_month).strftime('%m/%Y') != dt.datetime.now().strftime('%m/%Y'):
    # #     st.error("Not a Forecast Month")
    
    # forecast_duration = st.number_input("Enter the number of months for forecast:", min_value=12, value=36)
    # if (int(forecast_duration) > 108) or (int(forecast_duration) < 12):
    #     st.error("Enter Correct Forecasting Period")
    
    # # grouping_frequency_options = ["Monthly", "Quarterly", "Bi-Annual", "Annual"]
    # # grouping_interval = st.selectbox("Select grouping frequency:", grouping_frequency_options, key='grouping_interval')
    
    # # iternum = st.number_input("Enter the attempt number:", min_value = 1)

    # # Save inputs to session
    # # st.session_state.country_name = country
    # # st.session_state.operator_name = operator
    # st.session_state.start_month = start_month
    # st.session_state.forecast_duration = forecast_duration
    # # st.session_state.grouping_frequency = grouping_interval
    # st.session_state.months = forecast_period(st.session_state.start_month, st.session_state.forecast_duration)

    # st.session_state.iternum = iternum
           
    # # Display the sum of all final rates
    # st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
    # cols = st.columns([2,6,1,8,2])
    # with cols[1]:
    #     if st.button("Input Baselease Rates First"):
    #         if st.session_state.user == True:
    #             st.success("Taking you to change Base Lease Rates ➡️➡️➡️ ")
    #             st.session_state.current_page = 'baselease'
    #             st.rerun() 
    #         else:
    #             st.error("Please Fill complete details")   

    # with cols[3]:
    #     if st.button("Directly Input Escalation Values"):
    #         if st.session_state.user == True:
    #             st.success("Escalating You ➡️➡️➡️ ")
    #             st.session_state.current_page = 'esc'
    #             st.rerun()         
    #         else:
    #             st.error("Please Fill complete details")   
    

# if __name__ == "__main__":
#     initial()
