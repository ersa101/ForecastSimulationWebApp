import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from functions import forecast_period


def jumpto():
        
    # Display choice of page
    cols = st.columns([10,10])
    with cols[0]:
        st.write("Start with Changing Base Lease Rates of Components for Forecasting Period")
        st.write("THEN move on to changing the Future escalation values")
        st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
        if st.button("Input Baselease Rates First"):
            st.success("Taking you to change Base Lease Rates ➡️➡️➡️ ")
            st.session_state.current_page = 'baselease'
            st.rerun()  

    with cols[1]:
        st.write("IGNORE Changing Base Lease Rates of Components for Forecasting Period")
        st.write("DIRECTLY move on to changing the Future escalation values")
        st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
        if st.button("Directly Input Escalation Values"):
            st.success("Escalating You ➡️➡️➡️ ")
            st.session_state.current_page = 'esc'
            st.rerun()         
