import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
from functions import format_with_commas, linechart_dataframe


def plot():
    st.title("Forecasting Results")

    # Plots
    hist_period = st.sidebar.number_input("Enter Historical Period ", value=24)
    print(type(hist_period), hist_period)

    req_hist_future_df = linechart_dataframe(st.session_state.hist_blr_esc_cfv_master, st.session_state.final_future_esc_blrs, st.session_state.cntry_reg_twrs, hist_period)
    st.session_state.req_hist_future_df = req_hist_future_df
    # req_hist_future_df.to_csv(f"req_hist_future_df_{str(dt.datetime.now().strftime('%d%m%Y_%H%M%S'))}.csv", index=False)

    baseline_hist_future_df = pd.read_csv('Baseline_visua_160224_125013.csv')
    baseline_hist_future_df['Month'] = pd.to_datetime(baseline_hist_future_df['Month'])
    baseline_hist_future_df.drop(['pk_SAP_SiteTenantClass'], axis=1, inplace=True)
    # print(baseline_hist_future_df['Month'].unique())
    print(f"max forecast month is {st.session_state.months.months.max()}")
    st.session_state.baseline_hist_future_df = baseline_hist_future_df[baseline_hist_future_df.Month <= st.session_state.months.months.max()]
    st.session_state.baseline_hist_future_df = st.session_state.baseline_hist_future_df[st.session_state.baseline_hist_future_df.Month >= (st.session_state.months.months.min() - pd.DateOffset(months=int(hist_period)))]

    print(st.session_state.baseline_hist_future_df.shape)


    # filter for operator
    op_options = ['All'] + list(st.session_state.req_hist_future_df.Operator.unique())
    operator = st.sidebar.selectbox("Select Operator:", op_options, key='operator')
    st.session_state.operator_name = operator
    if st.session_state.operator_name == 'All':
        op_fltrd = st.session_state.req_hist_future_df.copy()
        op_fltrd_baseline = st.session_state.baseline_hist_future_df.copy()
    else:
        op_fltrd = st.session_state.req_hist_future_df[st.session_state.req_hist_future_df.Operator == st.session_state.operator_name]
        op_fltrd_baseline = st.session_state.baseline_hist_future_df[st.session_state.baseline_hist_future_df.Operator == st.session_state.operator_name]
    

    # filter for tenancy class 
    class_options = ['All'] + list(op_fltrd['Site Tenancy Classification'].unique())
    tenancy_class = st.sidebar.selectbox("Select Site Tenancy Class:", class_options, key='tenancy_class')
    if tenancy_class == 'All':
        class_fltrd = op_fltrd.copy()
        class_fltrd_baseline = op_fltrd_baseline.copy()
    else:
        class_fltrd = op_fltrd[op_fltrd['Site Tenancy Classification'] == tenancy_class]
        class_fltrd_baseline = op_fltrd_baseline[op_fltrd_baseline['Site Tenancy Classification'] == tenancy_class]



    # filter for Region
    reg_options = ['All'] + list(class_fltrd.Region.unique())
    reg = st.sidebar.selectbox("Select Site Region:", reg_options, key='reg')
    if reg == 'All':
        final_fltrd = class_fltrd.copy( )
        final_fltrd_baseline = class_fltrd_baseline.copy()
    else:
        final_fltrd  = class_fltrd[class_fltrd.Region == reg]
        final_fltrd_baseline = class_fltrd_baseline[class_fltrd_baseline.Region == reg]

    
    ## Buttons in the left sidebar
    # show_graph = st.sidebar.button("Show Graph 📈")
    # show_table = st.sidebar.button("Show Table 📅")
    st.sidebar.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
    # download_button = st.sidebar.button("Download XLSX 📑")
    st.sidebar.markdown('<div style="margin-bottom:20px;"></div>', unsafe_allow_html=True)
    restart = st.sidebar.button("Start Again 🤯")


    ## filtering the contributing parameters in dropdown
    not_int = ['Month', 'Site Tenancy Classification', 'Operator', 'Country', 'SAP Customer No', 'Region']
    numeric_cols = list(set(final_fltrd.columns) - set(not_int))
    final_fltrd[numeric_cols] = final_fltrd[numeric_cols].astype('float64')
    average_values = final_fltrd[numeric_cols].mean().to_dict()
    zero_cols = [k for k,v in average_values.items() if v==0]
    plottable_cols = list(set(numeric_cols) - set(zero_cols))
    print(plottable_cols)
    final_fltrd_cnvrtd = final_fltrd[not_int + plottable_cols]

    # numeric_cols_baseline = list(set(final_fltrd_baseline.columns) - set(not_int))
    final_fltrd_baseline[numeric_cols] = final_fltrd_baseline[numeric_cols].astype('float64')
    average_values_baseline = final_fltrd_baseline[numeric_cols].mean().to_dict()
    zero_cols_baseline = [k for k,v in average_values_baseline.items() if v==0]
    plottable_cols_baseline = list(set(numeric_cols) - set(zero_cols_baseline))
    print(plottable_cols_baseline)
    final_fltrd_cnvrtd_baseline = final_fltrd_baseline[not_int + plottable_cols_baseline]

    print(final_fltrd_cnvrtd.shape, final_fltrd_cnvrtd_baseline.shape)



    # Plot_1
    st.markdown('<p style="color: seagreen; font-size: 28px; font-weight: bold;"> 1. Heat Map Trend Across Regions </p>', unsafe_allow_html=True)
    visua1 = final_fltrd_cnvrtd[['Region', 'Month', 'tower_count', 'Revenue']]
    visua1 = visua1[visua1.Month >= st.session_state.start_month]
    p1 = visua1.groupby('Region').agg({'Revenue':'sum', 'tower_count':'mean'}).reset_index()
    fig1 = px.scatter(p1, x='Revenue', y='tower_count', color='Region', size='Revenue') #, title='Scatter Plot by Region')
    fig1.update_layout(
        xaxis_title='Revenue',
        yaxis_title=None, # 'Tower Count',
        showlegend=False
    )
    st.plotly_chart(fig1)

       
    
    # Plot_2
    st.markdown('<p style="color: seagreen; font-size: 28px; font-weight: bold;"> 2. Base Lease Rate & Revenue Trend Across Months </p>', unsafe_allow_html=True)
    # visua2 = final_fltrd_cnvrtd[['Month', 'Base Lease Rate', 'Revenue']]
    # p2 = visua2.groupby('Month')[['Base Lease Rate', 'Revenue']].sum().reset_index()
    # fig2 = px.line(p2, x='Month', y=['Base Lease Rate', 'Revenue'], markers=True)
    # fig2.add_shape(dict( type='line',
    #                     x0=pd.to_datetime(st.session_state.start_month),
    #                     x1=pd.to_datetime(st.session_state.start_month),
    #                     y0=0,
    #                     y1=p2.Revenue.max(),
    #                     line=dict(color='red', width=1),
    #                     )
    #                 )
    # fig2.update_layout( yaxis_title=None,  # Hide y-axis label
    #                     legend=dict(orientation='h', 
    #                                 yanchor='bottom', 
    #                                 y=-0.3, 
    #                                 xanchor='auto', 
    #                                 x=0.5),  # Show legend at the bottom
    #                 )
    # st.plotly_chart(fig2)
    
    # Assuming st.session_state.start_month is defined
    visua1 = final_fltrd_cnvrtd[['Month', 'Base Lease Rate', 'Revenue']]
    visua2 = final_fltrd_cnvrtd_baseline[['Month', 'Base Lease Rate', 'Revenue']]

    # Group and aggregate data for both DataFrames
    p1 = visua1.groupby('Month')[['Base Lease Rate', 'Revenue']].sum().reset_index()
    p2 = visua2.groupby('Month')[['Base Lease Rate', 'Revenue']].sum().reset_index()
    p2.rename(columns={'Base Lease Rate':'Predicted - BaseLeaseRate', 'Revenue':'Predicted - Revenue'}, inplace=True)

    # Create line plots
    fig2a = px.line(p1, x='Month', y=['Base Lease Rate', 'Revenue'], markers=True)
    fig2b = px.line(p2, x='Month', y=['Predicted - BaseLeaseRate', 'Predicted - Revenue'], markers=False)

    # Update layout for the combined chart
    fig2a.update_traces(marker=dict(size=4.5))
    fig2b.update_traces(line=dict(dash='dash'))
    fig2a.update_layout(
        xaxis_title=None, yaxis_title=None,  # Hide y-axis label
        legend=dict(orientation='h', yanchor='bottom', y=-0.3, xanchor='auto', x=0.5),  # Show legend at the bottom
    )

    # Add traces from the second plot to the first one
    for trace in fig2b.data:
        fig2a.add_trace(trace)

    # Add vertical line for start_month
    fig2a.add_shape(dict(
        type='line',
        x0=pd.to_datetime(st.session_state.start_month),
        x1=pd.to_datetime(st.session_state.start_month),
        y0=0,
        y1=p1.Revenue.max(),
        line=dict(color='red', width=1),
    ))

    # Show the combined plot
    st.plotly_chart(fig2a)



    # Plot_3
    st.markdown('<p style="color: seagreen; font-size: 28px; font-weight: bold;"> 3. Escalation Trend Across Months </p>', unsafe_allow_html=True)
    # colreq = [col for col in final_fltrd_cnvrtd.columns if '_Cumm' in col]
    # monthly_averages = final_fltrd_cnvrtd.groupby('Month')[colreq].mean()
    # fig3 = go.Figure()
    # for col in colreq:
    #     # fig3.add_trace(go.Scatter(x=final_fltrd['Month'], y=final_fltrd[col], mode='lines+markers', name=col, marker_size=3))
    #     fig3.add_trace(go.Scatter(x=monthly_averages.index, y=monthly_averages[col], mode='lines+markers', name=col, marker_size=3))
    # fig3.add_shape(dict( type='line',
    #                     x0=pd.to_datetime(st.session_state.start_month),
    #                     x1=pd.to_datetime(st.session_state.start_month),
    #                     y0=-30,
    #                     y1=75,
    #                     line=dict(color='red', width=1),
    #                     )
    #                 )
    # fig3.update_layout(  xaxis_title='Month',
    #                     yaxis_title=None,
    #                     legend=dict(orientation='h', 
    #                                 yanchor='bottom', 
    #                                 y=-0.5, 
    #                                 xanchor='auto', 
    #                                 x=0.5)
    #                 )
    # st.plotly_chart(fig3)
    

    colreq = [col for col in final_fltrd_cnvrtd.columns if '_Cumm' in col]

    final_fltrd_cnvrtd['Table'] = 'User'
    final_fltrd_cnvrtd_baseline['Table'] = 'Predicted'
    combined_data_cumm = pd.concat([final_fltrd_cnvrtd[['Month', 'Table'] + colreq], final_fltrd_cnvrtd_baseline[['Month', 'Table'] + colreq]], ignore_index=True)

    monthly_averages_cumm = combined_data_cumm.groupby(['Month', 'Table'])[colreq].mean().reset_index()

    fig_combined_cumm = go.Figure()
    for col in colreq:
        for table in monthly_averages_cumm['Table'].unique():
            table_data = monthly_averages_cumm[monthly_averages_cumm['Table'] == table]
            mode = 'lines+markers' if table == 'User' else 'lines'
            line_dash = 'solid' if table == 'User' else 'dash'
            fig_combined_cumm.add_trace(go.Scatter(
                x=table_data['Month'],
                y=table_data[col],
                mode=mode,
                name=f"{table} - {col}",
                marker_size=3,
                line=dict(dash=line_dash)
            ))

    # Add vertical line for start_month
    fig_combined_cumm.add_shape(dict(
        type='line',
        x0=pd.to_datetime(st.session_state.start_month),
        x1=pd.to_datetime(st.session_state.start_month),
        y0=monthly_averages_cumm[colreq].min().min(),
        y1=monthly_averages_cumm[colreq].max().max(),
        line=dict(color='red', width=1),
    ))

    # Update layout
    fig_combined_cumm.update_layout(
        # xaxis_title='Month',
        yaxis_title='Cummulative Values',
        legend=dict(orientation='h', yanchor='bottom', y=-0.8, xanchor='auto', x=0.5)
    )

    # Show the plot
    st.plotly_chart(fig_combined_cumm)


    # Download Table
    st.markdown('<div style="margin-bottom:110px;"></div>', unsafe_allow_html=True)
    st.markdown('<p style="color: teal; font-size: 28px; font-weight: bold;"> Download User Input and Final Output Tables </p>', unsafe_allow_html=True)
    with st.expander(':blue[**Expand to Download**]'):
    # with st.expander('<span style="color: teal; font-size: 28px; font-weight: bold;"> Download User Input and Final Output Tables </span>', unsafe_allow_html=True):
        cols = st.columns([6,1,6])
        with cols[0]:
            st.markdown('<p style="color: purple; font-size: 15px; font-weight: bold;"> User Input Base Lease Rate Components </p>', unsafe_allow_html=True)
            if st.session_state.input_blr.shape[0] > 0:
                st.write(st.session_state.input_blr)
            else:
                st.write("No Change in Future Base Lease Rate Component")
        with cols[2]:
            st.markdown('<p style="color: purple; font-size: 15px; font-weight: bold;"> User Input Escalations for Lease Rate Components </p>', unsafe_allow_html=True)
            if st.session_state.input_esc.shape[0] > 0:
                st.write(st.session_state.input_esc)
            else:
                st.write("No Change in Future Escalations of Lease Rate Component")

        st.markdown('<p style="color: purple; font-size: 15px; font-weight: bold;"> Output Table for filtered data </p>', unsafe_allow_html=True)
        frstcols = ['Month', 'Country', 'Operator', 'SAP Customer No', 'Site Tenancy Classification', 'Region', 'tower_count', 'Base Lease Rate', 'Revenue']
        othercols = [col for col in final_fltrd_cnvrtd.columns if (col not in frstcols) and (('_EscBlr' in col) or ('_MonthlyPerc' in col) or ('_CummPerc' in col))]
        
        show_table = final_fltrd_cnvrtd[final_fltrd_cnvrtd['Month'] >= (st.session_state.months.months.min() - pd.DateOffset(months=int(hist_period)))]
        show_table.fillna(0, inplace=True)
        show_table = show_table.reset_index(drop=True)
        show_table['Month'] = pd.to_datetime(show_table['Month']).dt.strftime('%b-%Y')
        show_table['Base Lease Rate'] = show_table['Base Lease Rate'].astype('int64')
        show_table['Revenue'] = show_table['Revenue'].astype('int64')
        st.write(show_table[frstcols + othercols])

       
    # # Show Graph button
    # if show_graph:
    #     st.plotly_chart(fig)

    # # Show Table button
    # if show_table:
    #     st.dataframe(st.session_state.visua_grp)

    # # Download XLSX button
    # if download_button:
    #     st.sidebar.success("Downloading your Compiled Data File ✌️✌️✌️")

    #     # final_fltrd_cnvrtd.to_csv(f"Operator_Class_Region_filtrd_hist_future_df_{str()}.csv", index=False)

    #     fltrd_req_hist_future_df = st.session_state.req_hist_future_df[st.session_state.req_hist_future_df.Month >= (st.session_state.months.months.min() - pd.DateOffset(months=int(hist_period)))]
    #     fltrd_req_hist_future_df['Month'] = pd.to_datetime(fltrd_req_hist_future_df['Month']).dt.strftime('%b-%Y')

    #     st.session_state.input_esc['Month'] = pd.to_datetime(st.session_state.input_esc['Month']).dt.strftime('%b-%Y')

    #     if 'time_identifier' not in st.session_state:
    #         st.session_state.time_identifier = dt.datetime.now().strftime('%d%m%Y_%H%M%S') 

    #     with pd.ExcelWriter(f"Simulated_Predicted_DataBook_{st.session_state.time_identifier}.xlsx") as writer:
    #         st.session_state.input_blr.to_excel(writer, sheet_name = "New Base Lease Rates", index=False)
    #         st.session_state.input_esc.to_excel(writer, sheet_name = "New Escalations", index=False)
    #         fltrd_req_hist_future_df.to_excel(writer, sheet_name = "Simulated Data", index=False)
            
            
    # Show Table button
    if restart:
        st.success("Taking you back to Initialization Screen 🔁🔁🔁")
        st.session_state.current_page = 'first'
        st.rerun()

# if __name__ == "__main__":
#     plot()
