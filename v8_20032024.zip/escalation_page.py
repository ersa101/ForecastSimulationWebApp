import streamlit as st
import pandas as pd
import numpy as np
import datetime as dt
import re
from dateutil.relativedelta import relativedelta
from functions import predata, baselease, esc, forecast_logic, linechart_dataframe, format_with_commas, forecast_period


def escalation():
    
    st.title("Change Future Escalation Values of Components")

    # Initialize session_state if not present
    if 'input_esc' not in st.session_state:
        st.session_state.input_esc = pd.DataFrame(columns=['Operator', 'Site Tenancy Classification', 'Parameter', 'Start Month', 'Value', 'Escalation Frequency'])
    if 'chk_parameter_list' not in st.session_state:
        st.session_state.chk_parameter_list = []
    if 'floor_ceil_caps' not in st.session_state:
        st.session_state.floor_ceil_caps = pd.read_csv('floor_ceil.csv')
    if 'input_blr' not in st.session_state:
        st.session_state.input_blr = pd.DataFrame(columns=['Operator', 'Site Tenancy Classification', 'Month','Change Parameter', 'Base Rate'])
    

    ## Country-Operator-SAP_ID mapping
    ctry_op_sap = {'Country' : ['Tanzania', 'Tanzania', 'Malawi'],
                'Operator' : ['Viettel', 'Tigo', 'Airtel'],
                'SAP Customer No' : ['C4.V00001', 'C4.M00001', 'C11.A00003']}
    ctry_op_sap_df = pd.DataFrame(ctry_op_sap)
    st.session_state.ctry_op_sap_df = ctry_op_sap_df
    
    # Reading CSV having complete historical data for ESC, CFV, BLR
    latest_all_data = pd.read_excel('prev_data.xlsx')
    filtrd_latest_all_data = latest_all_data.merge(st.session_state.ctry_op_sap_df, on = 'SAP Customer No', how = 'inner')
    st.session_state.filtrd_latest_all_data = filtrd_latest_all_data

    # Reading CSV having predicted data for ESC, BLR
    pred_df = pd.read_csv('Baseline_visua_160224_125013.csv')
    pred_df['Month'] = pd.to_datetime(pred_df['Month'])
    

    # Get Conditional Contributing parameters input
    if 'months' and 'forecast_duration' not in st.session_state:

        start_month = dt.datetime.now().strftime('%m/%Y')
        # start_month = pd.to_datetime(start_month).strftime('%m/%Y')
        st.sidebar.write(f"<span style='color: darkgray; font-size: 17px; font-weight: bold;'> Start Month for forecast as per latest data is  </span> <span style='color: purple; font-size: 20px; font-weight: bold;'> {start_month} </span> ", unsafe_allow_html=True)
        
        forecast_duration = st.sidebar.number_input("Enter the number of months for forecast:", min_value=12, value=36)
        if (int(forecast_duration) > 108) :
            st.sidebar.error("Enter Correct Forecasting Period")
        
        # Save inputs to session
        st.session_state.start_month = start_month
        st.session_state.forecast_duration = forecast_duration
        st.session_state.months = forecast_period(st.session_state.start_month, st.session_state.forecast_duration)

    else:
        st.sidebar.write(f"<span style='color: darkgray; font-size: 17px; font-weight: bold;'> Start Month for forecast as per latest data is </span> <span style='color: purple; font-size: 20px; font-weight: bold;'> {st.session_state.start_month} </span> ", unsafe_allow_html=True)
        st.sidebar.write(f"<span style='color: darkgray; font-size: 17px; font-weight: bold;'> Forecast Duration is </span> <span style='color: purple; font-size: 20px; font-weight: bold;'> {st.session_state.forecast_duration} </span> months ", unsafe_allow_html=True)


    with st.sidebar.expander("Upload Escalation CSV file"):
        # parameter_name_options = ["Non Power Escalation", "Fuel Escalation", "Electrical Escalation", "FX"]
                                  
        country = st.sidebar.selectbox("Select Country:", st.session_state.ctry_op_sap_df.Country.unique(), key='country')
        st.session_state.country_name = country
        
        filtrd_latest_all_data = filtrd_latest_all_data[filtrd_latest_all_data.Country == st.session_state.country_name]
        operator = st.sidebar.selectbox("Select Operator:", filtrd_latest_all_data.Operator.unique(), key='operator')
        st.session_state.operator_name = operator
        
        filtrd_latest_all_data = filtrd_latest_all_data[filtrd_latest_all_data.Operator == st.session_state.operator_name]
        tenancy_class = st.sidebar.selectbox("Select Site Tenancy Class:", filtrd_latest_all_data['Site Tenancy Classification'].unique(), key='tenancy_class')
        
        # filtering the contributing parameters in dropdown
        esc_selected_class = filtrd_latest_all_data[filtrd_latest_all_data['Site Tenancy Classification'] == tenancy_class]
        esc_params = list(esc_selected_class.columns)
        esc_cols = [cols for cols in filtrd_latest_all_data.columns if 'escmonthly__' in cols]
        esc_selected_class = esc_selected_class[esc_cols]
        esc_params = [col.split('__')[1] for col in esc_cols]
        # print(esc_params)
        col_rename_dict = dict(zip(esc_selected_class.columns, esc_params))
        esc_selected_class.rename(columns=col_rename_dict, inplace=True)
        filtered_cols = esc_selected_class.columns[esc_selected_class.min() != 0]
        esc_selected_class = esc_selected_class[filtered_cols]
        esc_parameters = [cols for cols in esc_selected_class.columns]
        print(esc_parameters)
        parameter_name = st.sidebar.selectbox("Select Lease Rate Component:", esc_parameters, key='parameter_name')
                                  
        parameter_start_month = st.sidebar.text_input("Enter Effective start month (MM/YYYY):", key='parameter_start_month')
        if len(parameter_start_month) == 7:
            try:
                parameter_start_month = (pd.to_datetime(parameter_start_month)).strftime('%b-%y')
                print(f"bl.1: {parameter_start_month}")
                if (pd.to_datetime(parameter_start_month, format='%b-%y') >= pd.to_datetime(st.session_state.months.months.min())) and  (pd.to_datetime(parameter_start_month, format='%b-%y') <= pd.to_datetime(st.session_state.months.months.max())):
                    st.sidebar.success("Month for Sought Change is CORRECT")
                    st.session_state.pred_dt = pd.to_datetime(parameter_start_month, format='%b-%y')
                    print(st.session_state.pred_dt)
                else:
                    st.sidebar.error("Month for Sought Change is INCORRECT or out of forecasting period")
            except Exception as e:
                print(e)
                st.error("Please Enter Correct Date")
                                  
        parameter_value = st.sidebar.number_input("Enter Escalation value:", key='parameter_value')
        pred_col = [col for col in pred_df.columns if ('_MonthlyPerc' in col) and (col.startswith(parameter_name))]
        print(f"col name for sought parameter is {pred_col[0]}   wherein other filters are {country}__{operator}__{tenancy_class}")
        if 'pred_dt' in st.session_state:
            pred_esc_val = round(pred_df[(pred_df.Country == country) & (pred_df.Operator == operator) & (pred_df['Site Tenancy Classification'] == tenancy_class) & (pred_df.Month == st.session_state.pred_dt)][pred_col[0]].min(),4)
            print(pred_esc_val)
            st.sidebar.write(f"<span style='color: red; font-size: 15px;'> Safe Predicted Value is  {pred_esc_val} </span> ", unsafe_allow_html=True)
                                  
        parameter_frequency_options = ["Monthly", "Quarterly", "Bi-Annual", "Annual"]
        parameter_frequency = st.sidebar.selectbox("Select parameter frequency:", parameter_frequency_options, key='parameter_frequency')
        
        # Display a "Save Changes" button
        st.sidebar.markdown('<div style="margin-bottom:10px;"></div>', unsafe_allow_html=True)
        if st.sidebar.button("Save/Upload Conditional Parameter"):
            new_parameter = {'Operator' : operator, 'Site Tenancy Classification' : tenancy_class,
                             'Parameter': parameter_name, 'Start Month': parameter_start_month, 
                             'Value': parameter_value, 'Escalation Frequency': parameter_frequency}
            chk_parameter = operator + tenancy_class + parameter_name + parameter_start_month
            print(chk_parameter, chk_parameter not in st.session_state.chk_parameter_list)
            user_esc = pd.DataFrame([new_parameter])
            
            if (len(parameter_start_month) == 6) and (chk_parameter not in st.session_state.chk_parameter_list) and (re.compile(r'^[a-zA-Z]{3}-\d{2}$').match(parameter_start_month)):
                if st.session_state.floor_ceil_caps.shape[0]>0:
                    temp = user_esc.merge(st.session_state.floor_ceil_caps, on = ['Site Tenancy Classification', 'Parameter'], how = 'left')
                    temp['UserValue'] = temp.Value
                    print(temp)
                    temp['Value'] = np.where(temp['Value'] > temp['Escalation_cap'],
                                                          (temp['Escalation_cap'] * temp['Escalation_multiplier'] / 100),
                                                           np.where(temp['Value'] > temp['Escalation_floor'],
                                                                    (temp['Value'] * temp['Escalation_multiplier'] / 100),
                                                                    np.where(((temp['Value'] != 0)) & (temp['Value'] < temp['Escalation_floor']),
                                                                             (temp['Escalation_floor'] * temp['Escalation_multiplier'] / 100),
                                                                             temp['Value']
                                                                            )
                                                                    )
                                                        )
                    temp = temp[['Operator', 'Site Tenancy Classification', 'Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
                st.session_state.input_esc = pd.concat([st.session_state.input_esc, temp], ignore_index=True)
                st.sidebar.success("Input parameter added Successfully ✅ ")
            elif (len(parameter_start_month) == 6) and (chk_parameter in st.session_state.chk_parameter_list):
                st.sidebar.error("Input parameter is Already Present ❌ ")
            else:
                st.sidebar.error("Input parameter is incomplete 😵‍💫 Check input Date format")
                
        
        # File uploader for CSV
        # st.sidebar.markdown('<div style="margin-bottom:10px;"></div>', unsafe_allow_html=True)
        uploaded_esc = st.file_uploader("Upload Escalation CSV file", type=["csv"], label_visibility='hidden')
        if uploaded_esc is not None:
            uploaded_esc = pd.read_csv(uploaded_esc)
            # uploaded_esc['Start Month'] = pd.to_datetime(uploaded_esc['Start Month'])
            print(uploaded_esc)
            print(uploaded_esc.shape)
            uploaded_esc['chk_parameters'] = uploaded_esc.Operator.astype(str) + uploaded_esc['Site Tenancy Classification'].astype(str) + uploaded_esc.Parameter.astype(str) +  uploaded_esc['Start Month'].astype(str)
            #  Avoiding Duplicates while repeated run
            new_uploads = list(set(uploaded_esc['chk_parameters']) - set(st.session_state.chk_parameter_list))
            uploaded_esc_rev = uploaded_esc[uploaded_esc.chk_parameters.isin(new_uploads)]
            uploaded_esc_rev = uploaded_esc_rev.drop('chk_parameters', axis=1)
            # checking for Floor_Ceil values
            if st.session_state.floor_ceil_caps.shape[0]>0:
                temp = uploaded_esc_rev.merge(st.session_state.floor_ceil_caps, on = ['Site Tenancy Classification', 'Parameter'], how = 'left')
                temp['UserValue'] = temp.Value
                print(temp)
                temp['Value'] = np.where(temp['Value'] > temp['Escalation_cap'],
                                                        (temp['Escalation_cap'] * temp['Escalation_multiplier'] / 100),
                                                        np.where(temp['Value'] > temp['Escalation_floor'],
                                                                (temp['Value'] * temp['Escalation_multiplier'] / 100),
                                                                np.where(((temp['Value'] != 0)) & (temp['Value'] < temp['Escalation_floor']),
                                                                            (temp['Escalation_floor'] * temp['Escalation_multiplier'] / 100),
                                                                            temp['Value']
                                                                        )
                                                                )
                                                    )
                uploaded_esc_rev = temp[['Operator', 'Site Tenancy Classification', 'Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
                print(f"Floor Ceil cap logic executed")
            print(f"revised Upload ESC data has shape {uploaded_esc_rev.shape}")
            st.session_state.input_esc = pd.concat([st.session_state.input_esc, uploaded_esc_rev], ignore_index=True)
    
    # Display the latest BLRs
    for i in range(esc_selected_class.shape[1]):
        st.write(f"Latest Escalation Value for Lease Rate Component <span style='color: blue; font-size: 17px; font-weight: bold;'>{esc_selected_class.columns[i]}</span>  is   <span style='color: blue; font-size: 17px; font-weight: bold;'>{round(esc_selected_class.iloc[0, i],2)}%</span>", unsafe_allow_html=True)

    # Display the updated DataFrame
    st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
    # st.write("Conditional Contributional / Escalation Parameters")
    st.markdown('<p style="color: black; font-size: 28px; font-weight: bold;"> Conditional Contributional / Escalation Parameters </p>', unsafe_allow_html=True)
    print(st.session_state.input_esc)
    st.session_state.input_esc.drop_duplicates(inplace = True)
    st.session_state.input_esc['chk_parameters'] = st.session_state.input_esc.Operator.astype(str) + st.session_state.input_esc['Site Tenancy Classification'].astype(str) + st.session_state.input_esc.Parameter.astype(str) +  st.session_state.input_esc['Start Month'].astype(str)
    st.session_state.chk_parameter_list = list(st.session_state.input_esc.chk_parameters.unique())
    print(st.session_state.chk_parameter_list)
    st.session_state.input_esc = st.session_state.input_esc[['Operator', 'Site Tenancy Classification', 'Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
    st.write(st.session_state.input_esc)
    
    
    # Move to Forecasting
    st.markdown('<div style="margin-bottom:40px;"></div>', unsafe_allow_html=True)
    cols = st.columns([1,5,1])
    # with cols[1]:
    #     if st.button("Input Addon Parameters & Discount"):
    #         st.success("Let's add additional Parameters & Discounts➡️➡️➡️ ")
    #         # st.session_state.input_esc = st.session_state.input_esc[['Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
    #         st.session_state.current_page = 'addon'
    #         st.rerun()               
    
    with cols[1]:
        if st.button("Forecast Now 🧮"):
            st.success("Moving you to Forecast ➡️➡️➡️ ")
            st.write(f"Performing forecast for {st.session_state.forecast_duration} months starting from {st.session_state.start_month}")
            # st.session_state.input_esc = st.session_state.input_esc[['Parameter', 'Start Month', 'Value', 'Escalation Frequency']]
            # Run the Simulations
            hist_blr_esc_cfv_master, final_future_esc_blrs, cntry_reg_twrs = forecast_logic(st.session_state.input_esc, st.session_state.input_blr, st.session_state.months)
            st.session_state.hist_blr_esc_cfv_master = hist_blr_esc_cfv_master
            st.session_state.final_future_esc_blrs = final_future_esc_blrs
            st.session_state.cntry_reg_twrs = cntry_reg_twrs
            
            st.session_state.time_identifier = dt.datetime.now().strftime('%d%m%Y_%H%M%S')                        
            with pd.ExcelWriter(f"OutputDataSimulatedPredicted_{st.session_state.username}_{st.session_state.time_identifier}.xlsx") as writer:
                st.session_state.input_blr.to_excel(writer, sheet_name = "NewBLRs", index=False)
                st.session_state.input_esc.to_excel(writer, sheet_name = "NewESCs", index=False)
                st.session_state.final_future_esc_blrs.to_excel(writer, sheet_name = "SimulatedDataAll", index=False)
            
            st.session_state.current_page = 'plot'
            st.rerun()

# if __name__ == "__main__":
#     escalation()
